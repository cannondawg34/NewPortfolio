import java.io.*;
import java.net.*;
import java.util.Random;

public class TCPServer {
    public static void main(String[] args) {
        int port = 6789; // this is the server port!
        String serverName = "Server of Cannon Dyer"; 
        Random random = new Random();
        int serverNumber = random.nextInt(100) + 1; //server #

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);

            while (true) {
                Socket connectionSocket = serverSocket.accept();
                System.out.println("Client connected");

                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

                // Read client message
                String clientMessage = inFromClient.readLine();
                System.out.println("Received: " + clientMessage);

                // Get client name and number
                String[] parts = clientMessage.split(": ");
                if (parts.length < 2) {
                    System.out.println("Invalid message format. Closing connection.");
                    connectionSocket.close();
                    continue;
                }

                String clientName = parts[0];
                int clientNumber;

                try {
                    clientNumber = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException e) {
                    System.out.println("Received an invalid number. Closing server.");
                    connectionSocket.close();
                    break; // Stops the server 
                }

                if (clientNumber < 1 || clientNumber > 100) {
                    System.out.println("Invalid number range. Closing server.");
                    connectionSocket.close();
                    break; // Stops the server
                }

                // Get sum
                int sum = clientNumber + serverNumber;

                // Prints results 
                System.out.println(clientName + " sent number: " + clientNumber);
                System.out.println(serverName + " has number: " + serverNumber);
                System.out.println("Sum: " + sum);

                // Send response to client
                String response = serverName + ": " + serverNumber;
                outToClient.writeBytes(response + "\n");

                // Close connection w client 
                connectionSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
