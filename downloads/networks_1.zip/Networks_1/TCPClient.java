import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TCPClient {
    public static void main(String[] args) {
        String serverIP = "localhost"; 
        int port = 6789;
        Scanner scanner = new Scanner(System.in);

        //this dials the server and creates two stream wrappers
        //DataOutputStream to send bytes to the server.
        //BufferedReader to read line-oriented text from the server.
        try (Socket clientSocket = new Socket(serverIP, port);
             DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
             BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {

            // Get user input
            System.out.print("Enter your name: ");
            String clientName = scanner.nextLine();

            //Gets a number from user. If invalid, loops back
            int clientNumber;
            while (true) {
                System.out.print("Enter an integer (1-100): ");
                clientNumber = scanner.nextInt();
                if (clientNumber >= 1 && clientNumber <= 100) {
                    break;
                } else {
                    System.out.println("Invalid input. Please enter a number between 1 and 100.");
                }
            }

            // Send data to server
            String message = "Client of " + clientName + ": " + clientNumber;
            outToServer.writeBytes(message + "\n");

            // Receive response from server
            String serverResponse = inFromServer.readLine();
            System.out.println("FROM SERVER: " + serverResponse);

            // Get data from server response
            String[] responseParts = serverResponse.split(": ");
            if (responseParts.length == 2) {
                String serverName = responseParts[0];
                int serverNumber = Integer.parseInt(responseParts[1]);

                // get sum
                int sum = clientNumber + serverNumber;
                System.out.println(clientName + "'s number: " + clientNumber);
                System.out.println(serverName + "'s number: " + serverNumber);
                System.out.println("Sum: " + sum);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}


