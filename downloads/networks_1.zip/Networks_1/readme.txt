Cannon Dyer (811)013669

How to run the program: Open the project folder in vs code or, whatever your prefered IDE. Go to terminal and cd into the folder provided. 
run javac -d bin TCPServer.java and then do the same command again for TCPClient.java. Finally, create another terminal window, cd into the
folder provided, and run java -cp bin .\TCPServer.java. In the other terminal window, run java -cp bin .\TCPClient.java. After that, follow 
program instructions and it should work correctly!

Operating Systems: OS Name:      Microsoft Windows 10 Home
		   OS Version:   10.0.19045 N/A Build 19045
Java libraries used:java.io., java.net., java.util.Scanner.