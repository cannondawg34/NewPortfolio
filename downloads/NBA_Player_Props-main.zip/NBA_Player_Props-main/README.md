# NBA_Props

🏀 NBA Props Optimizer
This project is a data-driven application that scrapes real-time NBA player statistics and PrizePicks prop lines, then applies machine learning models to identify high-probability picks. This project demonstrates the full pipeline of data acquisition, processing, modeling, and deployment.

📌 Key Features
🔍 Web Scraping: Real-time NBA player stats and PrizePicks lines using BeautifulSoup, requests, and Selenium or PrizePicks API

📊 Data Storage: PostgreSQL database to store player stats, props, and model predictions

🧠 Machine Learning: Neural networks and other models trained to predict player performance and prop line outcomes

🧪 Training & Evaluation: Clean data split into training/testing sets with preprocessing pipelines

🚀 Backend API: Python-based backend (Flask or FastAPI) to serve predictions

🖥️ Frontend to display best bets and player info

desired project strucutre:
nba-props-app/
├── backend/       # API, scraping, model inference, DB logic
├── frontend/      # (Optional) UI with React or templates
├── data/          # Raw and processed datasets
├── ml/            # Training, testing, model building
├── notebooks/     # EDA and model experiments
├── scripts/       # Dev utilities (e.g., DB init)
└── README.md




 
