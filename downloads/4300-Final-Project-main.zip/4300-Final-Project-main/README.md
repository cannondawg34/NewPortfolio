# 4300-Final-Project
Final project for 4300 Spring 2024

Be sure to install npm and other dependencies, the most recent node, and axios
```bash
npm install
nvm install
nvm use node
npm install axios

npm uninstall bcrypt
npm install bcrypt
npm rebuild
npm cache clean --force

```

Also be sure to edit the mongoDB connection string in the ConnectDB.js file

According to package.json run the app script to use nodemon with starting the server.
```bash
npm run app
# or
yarn app
# or
pnpm app
# or
bun app
```
