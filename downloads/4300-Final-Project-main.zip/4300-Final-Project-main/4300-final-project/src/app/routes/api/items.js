// routes/api/items.js
const express = require('express');
const router = express.Router();
const Item = require('../../models/Item');

// Get all items
router.get('/', async (req, res) => {
    try {
        const items = await Item.find();
        if (items.length === 0) {
            res.status(200).json([]);
        } else {
            res.json(items); // Send the found items
        }
    } catch (err) {
        res.status(500).json({ message: err.message }); // Send a 500 error for any server issues
    }
});

// Create a new item
router.post('/', async (req, res) => {
    const item = new Item({
        title: req.body.title,
        description: req.body.description,
        imageUrl: req.body.imageUrl,
        author: req.body.author
    });
    try {
        const newItem = await item.save();
        res.status(201).json(newItem);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Assuming you have a route set up like this
router.delete('/:id', async (req, res) => {
    try {
        const result = await Item.findByIdAndDelete(req.params.id);
        if (!result) {
            return res.status(404).send('Item not found');
        }
        res.send('Item deleted');
    } catch (error) {
        res.status(500).send('Server error');
    }
});

router.put('/:id', async (req, res) => {
    const { title, description } = req.body;
    try {
        const updatedItem = await Item.findByIdAndUpdate(req.params.id, { title, description }, { new: true });
        if (!updatedItem) {
            return res.status(404).send('Item not found');
        }
        res.json(updatedItem);
    } catch (error) {
        res.status(500).send('Server error');
    }
});



module.exports = router;
