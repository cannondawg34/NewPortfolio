// src/app/routes/api/users

const express = require('express');
const router = express.Router();
var bodyParser = require("body-parser");

const User = require('../../models/User');
const bcrypt = require('bcrypt');

    router.get('/', (req, res) => {
        User.find()
            .then(users => res.json(users))
            .catch(err => res.status(404).json({ noUsersFound: 'No users found.' }));
    });

    router.get('/:id', (req, res) => {
        User.findById(req.params.id)
            .then(user => res.json(user))
            .catch(err => res.status(404).json({ noUserFound: 'No user found with that ID.' }));
    });

    router.post('/', bodyParser.json(), (req, res) => {
        User.create(req.body)
            .then(user => res.json({ msg: 'User added successfully' }))
            .catch(err => res.status(400).json({ error: 'Failed to add user' }));
    });


// Signup route
router.post('/signup', async (req, res) => {
    const { username, password } = req.body;

    try {
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ msg: 'User already exists' });
        }

        /**
        const hashedPassword = await bcrypt.hash(password, 8);
        const newUser = new User({
            username,
            password: hashedPassword
        }); */

            // Create a new user instance and rely on the middleware(model) to hash the password
        const newUser = new User({
                username,
                password // Not hashing here, the model's pre-save will handle it
            });


        await newUser.save();
        res.status(201).json({ msg: 'User registered successfully', user: { id: newUser._id, username: newUser.username } });
    } catch (err) {
        res.status(500).json({ msg: "Internal server error", error: error.toString() });}
});

// Login route
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        console.log(`Attempting login for ${username}`); // Log the attempt
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ msg: 'User does not exist' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ msg: 'Invalid credentials' });
        }

        res.json({ msg: 'Logged in successfully', username: user.username }); // Ensure username is sent
    } catch (err) {
        console.log(err); // Log any server errors
        res.status(500).json({ error: 'Server error' });
    }
});


    router.put('/:id', bodyParser.json(), (req, res) => {
        User.findByIdAndUpdate(req.params.id, req.body, { new: true })
            .then(user => res.json({ msg: 'Updated user successfully' }))
            .catch(err => res.status(400).json({ error: 'Unable to update the user' }));
    });

    router.delete('/:id', (req, res) => {
        User.findByIdAndDelete(req.params.id)
            .then(user => res.json({ msg: 'User deleted successfully' }))
            .catch(err => res.status(404).json({ error: 'No such user' }));
    });

module.exports = router;