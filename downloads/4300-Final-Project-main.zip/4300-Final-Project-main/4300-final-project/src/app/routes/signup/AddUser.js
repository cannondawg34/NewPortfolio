'use client';
import './signup.css';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
//import { useRouter } from 'next/router';
import axios from 'axios';
import Card from '../../components/Card';
import Button from './Button';
import './AddUser.css';
import './Button.css';

const AddUser = () => {

    const router = useRouter();
    const [enteredUsername, setEnteredUsername] = useState('');
    const [enteredPassword, setEnteredPassword] = useState('');
    const [enteredConfirmPassword, setEnteredConfirmPassword] = useState('');
    const [error, setError] = useState(''); // State for holding an error message


    const submitHandler = async (event) => {
        event.preventDefault();
        if (enteredPassword !== enteredConfirmPassword) {
            setError("Passwords do not match.");
            return;
        }

        try {
            const response = await axios.post('/api/users/signup', {
                username: enteredUsername,
                password: enteredPassword
            });
            if (response.status === 201) {
                alert(response.data.msg);
                router.push('./login');
            } else {
                setError(error.response?.data?.msg || 'Failed to sign up.');
            }
        } catch (error) {
            setError(error.response?.data?.msg || 'Failed to sign up.');
            console.error('Signup error:', error);
        }

        // Clear input fields after attempting to submit
        setEnteredUsername('');
        setEnteredPassword('');
        setEnteredConfirmPassword('');
    };

    const handleLoginRedirect = () => {
        router.push('./login'); // Redirect to the login page
    };

    return (
        <Card className="input">
            <form onSubmit={submitHandler}>
                <div className="input-section">
                    <label htmlFor="username" className="input-label">Username</label>
                    <input
                        id="username"
                        type="text"
                        placeholder="Username"
                        value={enteredUsername}
                        onChange={(event) => setEnteredUsername(event.target.value)}
                        required
                    />
                </div>
                <div className="input-section">
                    <label htmlFor="password" className="input-label">Password</label>
                    <input
                        id="password"
                        type="password"
                        placeholder="Password"
                        value={enteredPassword}
                        onChange={(event) => setEnteredPassword(event.target.value)}
                        required
                    />
                </div>
                <div className="input-section">
                    <label htmlFor="confirm-password" className="input-label">Confirm Password</label>
                    <input
                        id="confirm-password"
                        type="password"
                        placeholder="Confirm Password"
                        value={enteredConfirmPassword}
                        onChange={(event) => setEnteredConfirmPassword(event.target.value)}
                        required
                    />
                </div>
                {error && <div className="errorMessage">{error}</div>} {/* Display error message if it exists */}
                <Button type="submit" className="button">Sign Up</Button>
                <Button type="button" className="button" onClick={handleLoginRedirect}>Already have Account?(Login)</Button>
            </form>
        </Card>
    );
};

export default AddUser;
