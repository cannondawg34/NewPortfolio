//signup/page.js
'use client';
import React from 'react';

import Hdr from '../../components/Hdr';
import dynamic from 'next/dynamic';
const AddUser = dynamic(() => import('./AddUser'), { ssr: false });

function SignupPage() {


    return (
        <div>
            <Hdr />
            <AddUser />
        </div>
    );
}

export default SignupPage;
