import React from 'react';
import Link from 'next/link';

import './Button.css';

// this will need to be later rewritten to also be a link
const Button = (props) => {
  return (
    <button
      className="button"
      type={props.type || 'button'}
      onClick={props.onClick}
    >
      {props.children}
    </button>
  );
};

export default Button;
