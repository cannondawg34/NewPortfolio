// home/imageCard
import React, { useState } from 'react';
import './ImageCard.css';

const ImageCard = ({ image, onEdit, onDelete, isAuthor }) => {
    const [editMode, setEditMode] = useState(false);
    const [title, setTitle] = useState(image.title);
    const [description, setDescription] = useState(image.description);

    const handleSave = () => {
        onEdit(image._id, title, description);
        setEditMode(false);
    };

    return (
        <div className="image-card">
            <img src={image.imageUrl} alt={image.description} />
            <div className="image-info">
                {editMode ? (
                    <>
                        <input value={title} onChange={e => setTitle(e.target.value)} />
                        <textarea value={description} onChange={e => setDescription(e.target.value)} />
                        <button onClick={handleSave}>Save</button>
                        <button onClick={() => setEditMode(false)}>Cancel</button>
                    </>
                ) : (
                    <>
                        <h2>{image.title}</h2>
                        <p>{image.description}</p>
                        {isAuthor && (
                            <div>
                                <button onClick={() => setEditMode(true)}>Edit</button>
                                <button onClick={() => onDelete(image._id)}>Delete</button>
                            </div>
                        )}
                    </>
                )}
                <p>Posted by: {image.author}</p>
                <p>On: {new Date(image.dateAdded).toLocaleDateString()}</p>
            </div>
        </div>
    );
};

export default ImageCard;
