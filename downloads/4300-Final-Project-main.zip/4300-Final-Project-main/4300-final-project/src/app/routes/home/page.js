// home/page.js xd
"use client"
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../../layout';
import { useRouter } from 'next/navigation';
import ImageCard from './ImageCard';

const HomePage = () => {
    const router = useRouter();
    const [items, setItems] = useState([]);
    const [username, setUsername] = useState('Guest');
    const [addingItem, setAddingItem] = useState(false);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [imageUrl, setImageUrl] = useState('');

    useEffect(() => {
        const storedUsername = localStorage.getItem('username');
        setUsername(storedUsername || 'Guest');
        fetchItems();
    }, []);

    const fetchItems = async () => {
        try {
            const response = await axios.get('/api/items');
            setItems(response.data);
        } catch (error) {
            console.error('Failed to fetch items:', error);
        }
    };



    const handleEdit = async (id, title, description) => {
        try {
            const response = await axios.put(`/api/items/${id}`, { title, description });
            const updatedItem = response.data;
            setItems(items.map(item => item._id === id ? { ...item, title: updatedItem.title, description: updatedItem.description } : item));
        } catch (error) {
            console.error('Failed to edit item:', error);
            alert(`Failed to edit item: ${error.response?.data || error.message}`);
        }
    };


    const handleDelete = async (id) => {
        try {
            const response = await axios.delete(`/api/items/${id}`);
            if (response.status === 200) {
                setItems(items.filter(item => item._id !== id));
                alert('Item deleted successfully');
            } else {
                alert('Deletion was not confirmed by the server');
            }
        } catch (error) {
            console.error('Failed to delete item:', error);
            alert(`Failed to delete item: ${error.response?.data || error.message}`);
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post('/api/items', {
                title,
                description,
                imageUrl,
                author: username
            });
            setItems([...items, response.data]);
            setTitle('');
            setDescription('');
            setImageUrl('');
            setAddingItem(false); // Hide the form after submission
        } catch (error) {
            console.error('Error adding item:', error);
            alert(`Failed to add item: ${error.response?.data || error.message}`);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('username');
        router.push('./login'); // Route to login page after logout
    };

    const handleAddClick = () => {
        if (username === 'Guest') {
            alert('A non-logged in user cannot add an image');
            router.push('./login'); // Change to the correct route for your login page
        } else {
            setAddingItem(true);
        }
    };

    return (
        <Layout>
            <div>
                <h1>Welcome to Your Gallery, {username}</h1>
                <button onClick={handleLogout}>Logout</button>
                <button onClick={handleAddClick}>Add Art</button>
                {addingItem && (
                    <form onSubmit={handleSubmit}>
                        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" required />
                        <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" required />
                        <input value={imageUrl} onChange={e => setImageUrl(e.target.value)} placeholder="Image URL" required />
                        <button type="submit">Submit</button>
                    </form>
                )}
                <div>
                    {items.map(item => (
                        <ImageCard
                            key={item._id}
                            image={item}
                            onEdit={handleEdit}
                            onDelete={handleDelete}
                            isAuthor={username === item.author}
                        />
                    ))}
                    {items.length === 0 && <p>No art pieces found. Add some!</p>}
                </div>
            </div>
        </Layout>
    );
};

export default HomePage;

