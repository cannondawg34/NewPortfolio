// routes/login/page.js
'use client';

import { useRouter } from 'next/navigation';

import React, { useState } from 'react';
import Layout from '../../layout';
import './login.css';
import axios from 'axios';

const LoginPage = () => {
    console.log('login page');

    const router = useRouter();

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post('/api/users/login', { username, password });
            console.log(response);
            if (response.status === 200) {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', response.data.username);
                router.push('./home');
            } else {
                alert('Login error');
            }
        } catch (error) {
            alert('Login error: ' + (error.response?.data?.msg || 'Unknown error'));
        }
    };

    const handleSignup = () => {
        router.push('./signup'); // Adjust this path if your signup page has a different route
    };

    return (
        <Layout>
            <div className="login-page-container">
                <h1>Login Page</h1>
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        className="input-field"
                    />
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="input-field"
                    />
                    <button type="submit" className="submit-button">Login</button>
                    <div></div>
                    <button type="button" className="signup-button2 " onClick={handleSignup}>Create Account?</button>
                </form>
            </div>
        </Layout>
    );
};

export default LoginPage;
