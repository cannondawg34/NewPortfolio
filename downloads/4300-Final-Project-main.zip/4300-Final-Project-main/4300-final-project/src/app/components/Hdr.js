// src/app/components/Hdr.js
import React from 'react';

import './Hdr.css';

const Hdr = () => {
  return (
    <div className="hdr">
     <h1>Goon Gallery</h1>
    </div>
  );
};

export default Hdr;