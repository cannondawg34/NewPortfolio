// app/page.js
"use client"

import Layout from './layout'; // Adjust the path if your component is elsewhere
import Button from './components/Button';
import Hdr from './components/Hdr';
import styles from './page.module.css'; // Make sure you have this CSS module for styling

const Home = () => {

    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');

    return (
        <Layout>
            <Hdr />
            <div className={styles.container}>
                <h1 className={styles.welcomeMessage}>Welcome to Goon Gallery!</h1>
                <p className={styles.gooningStartsHere}>Gooning starts here.</p>

                <Button href="/routes/login">Login</Button>
                <Button href="/routes/signup">Create Account</Button>
                <Button href="/routes/home">I want to Goon Now</Button>


            </div>
        </Layout>
    );
};

export default Home;
