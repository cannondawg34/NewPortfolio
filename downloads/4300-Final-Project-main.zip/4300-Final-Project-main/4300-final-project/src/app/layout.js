// app/layout.js
import { Inter } from "next/font/google";
import Head from 'next/head';
import "./globals.css";

// Import the Inter font from Google Fonts
const inter = Inter({ subsets: ["latin"] });

function RootLayout({ children, title, description, className}) {
  return (
      <>
        <Head>
          <title>{title}</title>
          <meta name="description" content={description} />
          {/* Any other meta tags, like viewport, charset, etc. */}
        </Head>
        <body className={className}>
        {children}
        </body>
      </>
  );
}

export default RootLayout;
