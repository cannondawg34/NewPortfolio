// ../final-Prof/add.js

const express = require('express');
const next = require('next');
const cors = require('cors');

const dbConnect = require('./dbConnect');  // Adjust the path as necessary

const port = process.env.PORT || 8082;
const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev }); // had to make it so app is a Next rtaher
const handle = app.getRequestHandler();



app.prepare().then(() => {
    const server = express();
    server.use(cors());
    server.use(express.json());  // Ensures JSON parsing for API routes


    // Connect to the Database
    dbConnect();

    // API Routes
    const users = require('./src/app/routes/api/users');
    server.use('/api/users', users);  // Use the user API routes
    const items = require('./src/app/routes/api/items');
    server.use('/api/items', items); // items API routes

    // Handle other requests with Next.js
    server.get('*', (req, res) => handle(req, res));

    server.listen(port, () => console.log(`Server running at http://localhost:${port}`));
});
