// ../final-Prof/dbConnect
const mongoose = require('mongoose');

async function dbConnect() {

    // change this to your mongoDB connection string
    const conn_str = 'mongodb+srv://gcb10067:percocet30@database.dmnauai.mongodb.net/';
    mongoose.set('strictQuery', false);

    mongoose.connect(conn_str, {
    }).then(() => {
        console.log('MongoDB Connection Succeeded...');
    })
        .catch(err => {
            console.log(`Error in DB Connection ${err}`);
        });
}

module.exports = dbConnect;
