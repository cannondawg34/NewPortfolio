# Cinema_E_Booking_System
This is The Cinema E-Booking System project for
Software Engineering at The Univeristy of Georgia.
Team B3
Cameran Butryn, Ethan Campbell, Cannon Dyer, 
Azad Kazemi, Chloe O