import "../styles.css";
import { Link, useLocation, useNavigate } from "react-router-dom"; // Import useNavigate
import { useState } from "react";

export function OrderConfirmation() {
  const location = useLocation();
  const navigate = useNavigate(); // Hook to navigate to the previous page
  const { totalPrice, cardDetails } = location.state || { totalPrice: 0, cardDetails: null };

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [promoCode, setPromoCode] = useState(""); // State to hold promo code input
  const [discount, setDiscount] = useState(0); // State for discount percentage
  const [finalPrice, setFinalPrice] = useState(totalPrice); // State for recalculated price

  const handleSubmit = () => {
    setIsSubmitting(true);

    fetch(`http://localhost:8080/api/checkout/confirm?email=${sessionStorage.getItem("userEmail")}`, {
      method: "POST",
    })
      .then((response) => {
        if (!response.ok) throw new Error("Failed to confirm bookings.");
        return response.text();
      })
      .then((data) => {
        console.log("Success:", data);
        setIsSubmitted(true);
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Error while confirming bookings.");
      })
      .finally(() => setIsSubmitting(false));
  };

  const handlePromoCode = () => {
    if (!promoCode) {
      alert("Please enter a promotion code.");
      return;
    }

    // Fetch promo percentage from backend
    fetch(`http://localhost:8080/api/checkout/promotion?promoCode=${promoCode}`)
      .then((response) => {
        if (!response.ok) throw new Error("Invalid promotion code.");
        return response.json();
      })
      .then((data) => {
        const promoPercentage = data.percentage || 0;
        if (promoPercentage > 0) {
          setDiscount(promoPercentage);
          const discountAmount = (totalPrice * promoPercentage) / 100;
          setFinalPrice((totalPrice - discountAmount).toFixed(2));
          alert(`Promo applied! You saved ${promoPercentage}%`);
        } else {
          alert("Promotion code is not valid.");
        }
      })
      .catch((error) => {
        console.error("Error applying promo code:", error);
        alert("Invalid or expired promotion code.");
      });
  };

  const handleGoBack = () => {
    navigate(-1); // Go back to the previous page
  };

  return (
    <div className="wholepage">
      <h1 className="below">Order Confirmation</h1>
      <p>Total Price: ${finalPrice}</p>
      <p>
        Card Used:{" "}
        {cardDetails
          ? `${cardDetails.cardType} **** **** **** ${cardDetails.cardNumber.slice(-4)}`
          : "N/A"}
      </p>

      <div>
        <input
          type="text"
          placeholder="Enter promotion code"
          value={promoCode}
          onChange={(e) => setPromoCode(e.target.value)}
          disabled={discount > 0}
        />
        <button onClick={handlePromoCode} disabled={discount > 0}>
          Apply Promo Code
        </button>
      </div>

      <button
        className="FinishButton"
        onClick={handleSubmit}
        disabled={isSubmitting || isSubmitted}
      >
        {isSubmitting ? "Submitting..." : "Confirm"}
      </button>

      <div style={{ marginTop: "20px" }}>
      <button
        className="FinishButton"
        onClick={handleGoBack}
        disabled={isSubmitting || isSubmitted} // Disable when submitting or after submission
      >
        Go Back
      </button>

        <Link
          to="/"
          className={`linkk ${isSubmitting ? "disabled-link" : ""}`}
          onClick={(e) => isSubmitting && e.preventDefault()}
        >
          Home
        </Link>
      </div>

      {isSubmitted && (
        <p style={{ color: "green", marginTop: "10px" }}>
          Bookings confirmed successfully!
        </p>
      )}
    </div>
  );
}
