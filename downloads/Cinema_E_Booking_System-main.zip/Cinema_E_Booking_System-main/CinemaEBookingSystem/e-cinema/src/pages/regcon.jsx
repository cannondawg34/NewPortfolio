import "../styles.css"
import Navbar from "../components/Navbar"
import { Link, useLocation, useNavigate } from "react-router-dom"
import React, { useState } from "react";

export function RegistrationConfirmation() {
    const location = useLocation();
    const email = location.state?.email;
    const [code, setCode] = useState('');
    const [error, setError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [isSubmitDisabled, setIsSubmitDisabled] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isVerified, setIsVerified] = useState(false);
    const navigate = useNavigate();

    const handleCodeChange = (e) => {
        const value = e.target.value;

        // Only accept numeric input and limit to 6 digits
        if (/^\d*$/.test(value) && value.length <= 6) {
            setCode(value);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (code.length === 6 && parseInt(code) >= 100000 && parseInt(code) <= 999999) {
            setError('');
            setIsSubmitting(true); // Set submitting to true when request is made
            setIsSubmitDisabled(true); // Disable the submit button

            try {
                const response = await fetch('http://localhost:8080/api/users/verify-code-registration', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email, code }),
                });

                if (response.ok) {
                    console.log("Verification successful");
                    setSuccessMessage("Verification successful! Returning to homepage...");
                    setIsVerified(true); // Mark as verified

                    // Wait for 5 seconds before navigating to the home page
                    setTimeout(() => {
                        navigate('/');
                    }, 3000); // 5000ms = 5 seconds
                } else {
                    console.error("Verification failed");
                    setError("Incorrect verification code. Please try again.");
                }
            } catch (error) {
                console.error("Request failed:", error);
                setError("An error occurred. Please try again later.");
            } finally {
                setIsSubmitting(false); // Reset submitting state after response
                setIsSubmitDisabled(false); // Re-enable the submit button after response
            } // try
        } else {
            setError("Please enter a valid 6-digit verification code.");
        }
    };

    return (
        <>
            <Navbar />
            <div className="wholepage">
                <h1 className="below">Congrats! You have successfully registered your account!</h1>
                <p className="subtext">
                    Please check your email ({email}) for a 6-digit account verification code.
                </p>

                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
                    <div>
                        <label htmlFor="verificationCode">Enter Verification Code:</label>
                    </div>
                    <div>
                        <input
                            type="text"
                            id="verificationCode"
                            value={code}
                            onChange={handleCodeChange}
                            placeholder="Enter 6-digit code"
                            required
                            style={{ textAlign: "center", padding: "8px", width: "200px" }}
                            disabled={isSubmitDisabled || isVerified} // Disable input field while submitting
                        />
                    </div>
                    {error && <p className="error" style={{ color: "red" }}>{error}</p>}
                    <button 
                        type="submit" 
                        className="FinishButton" 
                        disabled={isSubmitDisabled || isSubmitting || isVerified} // Disable button while submitting
                    >
                        {isSubmitting ? "Submitting..." : "Submit Code"}
                    </button>
                </form>

                {successMessage && (
                    <p className="success" style={{ color: "green", textAlign: "center" }}>
                        {successMessage}
                    </p>
                )}

                <Link to="/" className="linkk">Home</Link>
            </div>
        </>
    );
}