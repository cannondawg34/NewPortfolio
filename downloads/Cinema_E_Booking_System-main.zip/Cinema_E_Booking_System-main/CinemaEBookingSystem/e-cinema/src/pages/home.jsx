import "../styles.css"
import Navbar from "../components/Navbar"
export function Home() {
    return <>
    <Navbar />
    <h1>Homepage</h1>
    </>
}