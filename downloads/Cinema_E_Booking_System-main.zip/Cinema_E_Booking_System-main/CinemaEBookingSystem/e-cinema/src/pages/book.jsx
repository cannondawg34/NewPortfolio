import "../styles.css";
import { useState, useEffect } from "react";
import { useLocation } from 'react-router-dom';
import { useNavigate } from "react-router-dom"
export function Book() {
    const navigate = useNavigate();
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const movieTitle = queryParams.get('title');
    const email = sessionStorage.getItem('userEmail');
    const [ages, setAges] = useState({});
    const [selectedSeats, setSeats] = useState(new Array(64).fill(false)); 
    const [showtimes, setShowtimes] = useState([]);
    const [selectedTime, setSelectedTime] = useState("");
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(true);
    const [unavailableSeats, setUnavailableSeats] = useState([]);

    useEffect(() => {
        const fetchShowtimes = async () => {
            setLoading(true);
            try {
                const response = await fetch(`http://localhost:8080/api/movies/schedule/${movieTitle}`);
                if (response.ok) {
                    const data = await response.json();

                    // Parse the schedule into usable date, time, and theater
                    const parsedSchedule = data.schedule.map((datetime) => {
                        // Split the datetime string into date, time, and theater parts
                        const [dateTimePart, theater] = datetime.split('$');
                        const [date, time] = dateTimePart.split(' ');  // ["YYYY-MM-DD", "HH:MM"]
                        return { date: date.trim(), time: time.trim(), theater: theater.trim() };
                    });

                    setShowtimes(parsedSchedule);
                } else {
                    console.error('Failed to fetch schedule');
                }
            } catch (error) {
                console.error('Error fetching showtimes:', error);
            } finally {
                setLoading(false);
            }
        };
        if (movieTitle) {
            fetchShowtimes();
        }
    }, [movieTitle]);
    // Fetch unavailable seats
    const fetchUnavailableSeats = async () => {
        try {
            const response = await fetch(`http://localhost:8080/api/showings/unavailable-seats?showtime=${encodeURIComponent(selectedTime)}`);
            if (response.ok) {
                const data = await response.json();
                console.log('Unavailable Seats:', data);
                if (data && Array.isArray(data)) {
                    setUnavailableSeats(data); // Only set state if the data is valid
                } else {
                    console.error("Invalid unavailableSeats data:", data);
                    setUnavailableSeats([]); // Set to empty array if data is invalid
                }
            } else {
                console.error("Failed to fetch unavailable seats");
                setUnavailableSeats([]); // Set to empty array on error
            }
        } catch (error) {
            console.error("Error fetching unavailable seats:", error);
            setUnavailableSeats([]); // Set to empty array if an error occurs
        }
    };
    const addSeat = (seat) => {
        if (unavailableSeats.includes(seat)) return; // Prevent selection if the seat is unavailable
        const row = seat.charAt(0).toUpperCase(); // Extracting row (A, B, C, etc.)
        const col = parseInt(seat.charAt(1)) - 1; // Extracting column (1 to 8)
        const index = (row.charCodeAt(0) - 'A'.charCodeAt(0)) * 8 + col; // Mapping seat to index in the array (0 to 63)

        setSeats((prevSeats) => {
            const updatedSeats = [...prevSeats];
            updatedSeats[index] = !updatedSeats[index];
            if (updatedSeats[index]) {
                setAges((prevAges) => ({ ...prevAges, [seat]: '' })); // Add age input when seat selected
            } else {
                const { [seat]: _, ...rest } = ages; // Remove ages when seat deselected
                setAges(rest);
            }
            return updatedSeats;
        });
    };

    const handleAgeChange = (seat, value) => {
        setAges((prev) => ({
            ...prev,
            [seat]: value,
        }));
    };
    
    const handleNext = () => {
        setStep(2); // Move to seat selection 
        fetchUnavailableSeats();
    };
    const handleBack = () => {
        setStep(1); // Move back to showtime selection
        setSeats(new Array(64).fill(false));
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!email) {
            console.error("User email is missing.");
            return;
        }
        // Collect selected seats and ages
        const selectedWithAges = selectedSeats
            .map((isSelected, index) => {
                if (isSelected) {
                    const row = String.fromCharCode('A'.charCodeAt(0) + Math.floor(index / 8));
                    const col = (index % 8) + 1;
                    const seat = `${row}${col}`;
                    return { seat, age: ages[seat] || '' };
                }
                return null;
            })
            .filter(Boolean);
        const bookingData = {
            email,
            selectedTime,
            selectedSeats: selectedWithAges,
        };
        console.log("Booking Data (JSON to be sent):", JSON.stringify(bookingData, null, 2));
        // Send data to backend
        try {
            const response = await fetch('http://localhost:8080/api/showings/savebooking', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(bookingData),
            });

            if (response.ok) {
                console.log("Booking successful!");
                navigate("/bookcon");
            } else {
                console.error("Failed to book the tickets.");
            }
        } catch (error) {
            console.error("Error booking the tickets:", error);
        }
    };

    // Check if all selected seats have a non-empty age value
    const isFormValid = selectedSeats.some((seat) => seat) &&
        Object.keys(ages).every((seat) => ages[seat]);

        return (
            <>
                <div className="wholepage">
                    <h1 className="below">Book Tickets</h1>
                    <h4>{movieTitle}</h4>
    
                    {step === 1 && (
                        <>
                            <h4>Select Showing:</h4>
                            <div>
                                {loading ? (
                                    <p>Loading...</p>
                                ) : showtimes.length > 0 ? (
                                    showtimes.map((showtime, index) => (
                                        <div key={index} className="radio-option">
                                            <input
                                                type="radio"
                                                id={`time-${index}`}
                                                name="showtime"
                                                value={`${showtime.date} ${showtime.time} ${showtime.theater}`}
                                                checked={selectedTime === `${showtime.date} ${showtime.time} ${showtime.theater}`}
                                                onChange={() => setSelectedTime(`${showtime.date} ${showtime.time} ${showtime.theater}`)}
                                            />
                                            <label htmlFor={`time-${index}`}>
                                                {showtime.date} {showtime.time} {showtime.theater}
                                            </label>
                                        </div>
                                    ))
                                ) : (
                                    <p>No showtimes available</p>
                                )}
                            </div>
                            {!email && (
                                <button onClick={() => navigate('/login')}>
                                    Log in to Book Tickets
                                </button>
                            )}
                            <button
                                type="button"
                                className="nextButton"
                                onClick={handleNext}
                                disabled={!selectedTime || !email}
                            >
                                Next
                            </button>
                        </>
                    )}
    
                    {step === 2 && (
                        <>
                            <h4>Selected Showing: {selectedTime}</h4>
                            <h4>Select Seats:</h4>
                            <div className="theater">Front</div>
                            <div className="rows">
                                {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map((row) => (
                                    <div className="col" key={row}>
                                        {[...Array(8)].map((_, idx) => {
                                            const seat = `${row}${idx + 1}`;
                                            const seatIndex = (row.charCodeAt(0) - 'A'.charCodeAt(0)) * 8 + idx;
                                            const isUnavailable = unavailableSeats.includes(seat);
    
                                            return (
                                                <div key={seat}>
                                                    <label htmlFor={seat}>{seat}</label>
                                                    <input
                                                        type="checkbox"
                                                        id={seat}
                                                        checked={selectedSeats[seatIndex]}
                                                        onChange={() => addSeat(seat)}
                                                        disabled={isUnavailable}
                                                    />
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>
                            <div className="theater">Back</div>
                            <h4>Enter Ages for Selected Seats:</h4>
                            <div className="age-inputs">
                                {selectedSeats.map((isSelected, index) => {
                                    if (!isSelected) return null;
                                    const row = String.fromCharCode('A'.charCodeAt(0) + Math.floor(index / 8));
                                    const col = (index % 8) + 1;
                                    const seat = `${row}${col}`;
                                    return (
                                        <div key={seat}>
                                            <label htmlFor={seat}>{seat}</label>
                                            <input
                                                type="number"
                                                id={seat}
                                                placeholder="Age"
                                                value={ages[seat] || ''}
                                                onChange={(e) => handleAgeChange(seat, e.target.value)}
                                            />
                                        </div>
                                    );
                                })}
                            </div>
                            <button type="button" className="backButton" onClick={handleBack}>Back</button>
                            <input
                                type="submit"
                                className="FinishButton"
                                onClick={handleSubmit}
                                disabled={!isFormValid}
                            />
                        </>
                    )}
                </div>
            </>
        );
    }

