import "../styles.css"
import React, { useState, useEffect } from 'react';
export function Promotion() {
  const [promotions, setPromotions] = useState([]);
  useEffect(() => {
    fetch('http://localhost:8080/api/users/promotions')
      .then((response) => response.json())
      .then((data) => {
        setPromotions(data);
      })
      .catch((error) => console.error('Error fetching promotions:', error));
  }, []);
  return (
    <div className="wholepage">
      <div>
        <h1 className="below">Promotions</h1>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Percent</th>
            </tr>
          </thead>
          <tbody>
            {promotions.length === 0 ? (
              <tr>
                <td colSpan="3">No promotions available</td>
              </tr>
            ) : (
              promotions.map((promotion, index) => (
                <tr key={index}>
                  <td>{promotion.name}</td>
                  <td>{promotion.percent}%</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}