import "../styles.css";
import { Link } from "react-router-dom";
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const LogIn = ({ setIsLoggedIn }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showVerificationInput, setShowVerificationInput] = useState(false);
    const [verificationCode, setVerificationCode] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsSubmitting(true);

        try {
            const response = await fetch('http://localhost:8080/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            const responseData = await response.json();
            if (!response.ok) {
                console.log('Error message received:', responseData.message);
                if (responseData.statusCode === "NOT_VERIFIED") {
                    setShowVerificationInput(true);
                    setError("Account is not verified. Press the button to resend the verification code."); // Display error
                } else {
                    throw new Error(responseData.message || 'Login failed');
                }
            } else {

                console.log('Login successful:', responseData);
                setIsLoggedIn(true);
                sessionStorage.setItem('userEmail', email);
                // alert("You are logged in")
                if (responseData.isAdmin === true) {
                    setSuccess("Admin login successful. Navigating to admin page...");
                } else {
                    setSuccess("Success! Returning to the home page...");
                }
                setError('');
                setTimeout(() => {
                    if (responseData.isAdmin === true) {
                        navigate('/admin'); // Redirect to admin page if user is admin
                    } else {
                        navigate('/'); // Redirect to regular home page if not admin
                    }
                }, 2000);
            }
        } catch (error) {
            setError(error.message);
            setSuccess('');
            setIsSubmitting(false);
        }
    };

    const handleResendCode = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/login/resend-verification', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email }),
                mode: 'cors',
            });
            if (response.ok) {
                setSuccess("Verification code resent. Check your email.");
                setError('');
            } else {
                throw new Error('Failed to resend verification code');
            }
        } catch (error) {
            setError(error.message);
            setSuccess('');
        }
    };

    const handleVerificationSubmit = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/login/verify-code', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, verificationCode }),
            });
            if (response.ok) {
                setSuccess("Verification successful. Please log in.");
                setError('');
                setShowVerificationInput(false);
            } else {
                throw new Error('Invalid verification code');
            }
        } catch (error) {
            setError(error.message);
            setSuccess('');
        }
    };

    return (
        <div className="wholepage">
            <h1 className="below">Login</h1>
            <span>New User? Sign up </span>
            <Link className="linkk" to="/createaccount">here!</Link>
            <form onSubmit={handleSubmit}>
                <label htmlFor="email">Email: </label>
                <input
                    type="email" // Updated type to 'email' for better validation
                    id="email" // Updated id
                    placeholder="Your Email" 
                    value={email} // Updated to use email
                    onChange={(e) => setEmail(e.target.value)} // Updated to use setEmail
                    required
                />
                <br />
                <label htmlFor="password">Password: </label>
                <input
                    type="password"
                    id="password"
                    placeholder="Your Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <br />
                <input className="FinishButton" type="submit" value="Log In" disabled={isSubmitting}/>
                {error && <p style={{ color: 'red' }}>{error}</p>}
                {success && <p style={{ color: 'green' }}>{success}</p>} {/* Display success message */}
            </form>
            {showVerificationInput && (
                <div>
                    <button onClick={handleResendCode}>Resend Verification Code</button>
                    <input
                        type="text"
                        placeholder="Enter verification code"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value)}
                    />
                    <button onClick={handleVerificationSubmit}>Submit Code</button>
                </div>
            )}
            <button className="sign-in"><Link to="/forgotpassword">Forgot Password</Link></button>
        </div>
    );
}