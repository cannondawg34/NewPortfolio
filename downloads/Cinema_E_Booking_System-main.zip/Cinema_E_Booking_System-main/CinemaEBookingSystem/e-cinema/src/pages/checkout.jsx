import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "../styles.css";

export function Checkout() {
  const [bookingSummaries, setBookingSummaries] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [cardData, setCardData] = useState([]);
  const [selectedCard, setSelectedCard] = useState(""); // Track selected card
  const [isLoading, setIsLoading] = useState(true);
  const [hasNoBookings, setHasNoBookings] = useState(false);
  const userEmail = sessionStorage.getItem("userEmail");

  const navigate = useNavigate(); // Hook for navigation

  const fetchData = useCallback(() => {
    if (userEmail) {
      setIsLoading(true);

      // Fetch saved cards
      fetch("http://localhost:8080/api/users/cards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: userEmail }),
      })
        .then((response) => response.json())
        .then((data) => {
          const formattedCards = (data || []).map((card) => ({
            cardType: card.cardType || "",
            cardNumber: card.cardNumber || "",
            expiration: card.expirationDate || "",
          }));
          setCardData(formattedCards);
        });

      // Fetch booking summary
      fetch(`http://localhost:8080/api/checkout/summary?email=${userEmail}`)
        .then((response) => {
          if (response.status === 404) {
            setHasNoBookings(true);
            return null;
          }
          return response.json();
        })
        .then((data) => {
          if (data) {
            const groupedSummaries = groupByMovieTimeTheater(data.seatsDetails);
            setBookingSummaries(groupedSummaries);
            setTotalPrice(data.totalPrice);
          }
        })
        .finally(() => setIsLoading(false));
    }
  }, [userEmail]);

  useEffect(() => {
    fetchData();
  }, [userEmail, fetchData]);

  const groupByMovieTimeTheater = (seatsDetails) => {
    return seatsDetails.reduce((groups, seatDetail) => {
      const key = `${seatDetail.movieTitle} - ${seatDetail.timeSlot} - ${seatDetail.theaterName}`;
      if (!groups[key]) {
        groups[key] = {
          movieTitle: seatDetail.movieTitle,
          timeSlot: seatDetail.timeSlot,
          theaterName: seatDetail.theaterName,
          seats: [],
          bookingIds: [],
          subtotal: 0,
        };
      }
      groups[key].seats.push(seatDetail.seatLabel);
      groups[key].bookingIds.push(seatDetail.bookingId);
      groups[key].subtotal += seatDetail.price;
      return groups;
    }, {});
  };

  const deleteBooking = (bookingId) => {
    if (!bookingId) {
      console.error("Invalid booking ID:", bookingId);
      return;
    }
    fetch(`http://localhost:8080/api/checkout/delete?bookingId=${bookingId}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to delete booking");
        }
        return response.text();
      })
      .then((data) => {
        console.log("Booking deleted:", data);
        fetchData();
      })
      .catch((error) => console.error("Error deleting booking:", error));
  };

  const handleConfirm = (e) => {
    e.preventDefault();

    // Pass total price and selected card details to the confirmation page
    const cardDetails = cardData[selectedCard];
    navigate("/order-confirmation", {
      state: {
        totalPrice: totalPrice.toFixed(2),
        cardDetails: cardDetails,
      },
    });
  };

  return (
    <div className="wholepage">
      <h1 className="below">Checkout</h1>

      {isLoading ? (
        <p>Loading your booking summary...</p>
      ) : hasNoBookings ? (
        <p>You have no bookings!</p>
      ) : (
        Object.entries(bookingSummaries).map(([key, details]) => (
          <div key={key} className="movie-summary">
            <h2>{details.movieTitle}</h2>
            <p>
              <strong>Time:</strong> {details.timeSlot}
            </p>
            <p>
              <strong>Theater:</strong> {details.theaterName}
            </p>
            <p>
              <strong>Seats:</strong> {details.seats.join(", ")}
            </p>
            <p>
              <strong>Subtotal:</strong> ${details.subtotal.toFixed(2)}
            </p>
            {details.bookingIds.map((bookingId, i) => (
              <button
                key={`delete-${bookingId}`}
                onClick={() => deleteBooking(bookingId)}
                disabled={isLoading || hasNoBookings}
              >
                Delete {details.seats[i]}
              </button>
            ))}
          </div>
        ))
      )}

      {!isLoading && !hasNoBookings && (
        <h3>Total Price: ${totalPrice.toFixed(2)}</h3>
      )}

      <form onSubmit={handleConfirm}>
        {cardData.length > 0 && !hasNoBookings && (
          <div>
            <label htmlFor="savedCards">Select your card:</label>
            <select
              id="savedCards"
              name="savedCard"
              value={selectedCard}
              onChange={(e) => setSelectedCard(e.target.value)}
              disabled={isLoading || hasNoBookings}
            >
              <option value="">Select card</option>
              {cardData.map((card, index) =>
                card.cardType && card.cardNumber ? (
                  <option key={index} value={index}>
                    {card.cardType} **** **** **** {card.cardNumber.slice(-4)}
                  </option>
                ) : null
              )}
            </select>
          </div>
        )}
        <input className="FinishButton" type="reset" value="Cancel"></input>
        <input
          className="FinishButton"
          type="submit"
          value="Confirm"
          disabled={isLoading || hasNoBookings || selectedCard === ""}
        ></input>
      </form>
    </div>
  );
}
