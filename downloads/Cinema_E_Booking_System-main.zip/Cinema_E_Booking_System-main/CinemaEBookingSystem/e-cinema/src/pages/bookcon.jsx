import "../styles.css"
import { useNavigate } from "react-router-dom"
export function BookConfirmation() {
  const navigate = useNavigate();
  const handleCheckout = () => {
    navigate("/checkout");
  };
  const handleHome = () => {
    navigate("/");
  };
  return <>
    <div className="wholepage">
      <h1 className="below">You have successfully booked your tickets! Continue to checkout.</h1>
      <button onClick={handleCheckout} className="FinishButton">Continue to checkout</button>
      <button onClick={handleHome} className="FinishButton">Home</button>
    </div>
  </>
}