import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Breadcrumb = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);

  const formatPathSegment = (segment) => {
    if (segment === 'admin') {
      return 'Home';
    }

    if (segment.includes('-')) {
      return segment
        .split('-')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1)) 
        .join(' '); 
    }
    return segment.charAt(0).toUpperCase() + segment.slice(1);
  };

  return (
    <nav className="breadcrumb">
      {pathnames.length > 0 &&
        pathnames.map((value, index) => {
          const to = `/${pathnames.slice(0, index + 1).join('/')}`;
          
          // Change link for Schedule in the breadcrumb trail
          let customLink = to;
          if (value === 'schedule') {
            customLink = '/admin/movies';  
          }

          const formattedLabel = formatPathSegment(value);

          return (
            <span key={to}>
              {index > 0 && ' > '}
              <Link to={customLink}>{formattedLabel}</Link>
            </span>
          );
        })
      }
    </nav>
  );
};

export default Breadcrumb;