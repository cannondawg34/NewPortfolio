import { useParams } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import './HeroSection.css';
import { Link } from "react-router-dom";

const MovieDetail = ({ movies }) => {
  const { title } = useParams();
  const heroRef = useRef(null);
  const [showTrailer, setShowTrailer] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showtimes, setShowtimes] = useState([]);

  const movie = movies.find((movie) => 
    movie.title.toLowerCase().replace(/\s+/g, '-') === title
  );

  const handleWatchTrailer = () => {
    setShowTrailer(true);
  };

  useEffect(() => {
    if (heroRef.current) {
      heroRef.current.style.background = `url(${movie?.banner}) center center / cover no-repeat`;
    }
  }, [movie]);

  useEffect(() => {
    const fetchShowtimes = async () => {
      setLoading(true);
      try {
        const response = await fetch(`http://localhost:8080/api/movies/schedule/${movie?.title}`);
        if (response.ok) {
          const data = await response.json();
          const parsedSchedule = data.schedule.map((datetime) => {
            const [dateTimePart, theater] = datetime.split('$');
            const [date, time] = dateTimePart.split(' ');
            return { date: date.trim(), time: time.trim(), theater: theater.trim() };
          });
          setShowtimes(parsedSchedule);
        } else {
          console.error('Failed to fetch schedule');
        }
      } catch (error) {
        console.error('Error fetching showtimes:', error);
      } finally {
        setLoading(false);
      }
    };
    if (movie) {
      fetchShowtimes();
    }
  }, [movie]);

  return (
    <div>
      {movie ? (
        <div className="movie-detail">
          <section ref={heroRef} className="hero-section-movie">
            <div className="hero-content">
              <h1>{movie.title}</h1>
              <div className="buttons">
              <button>
                <Link to={`/book?title=${encodeURIComponent(movie.title)}`}>Get Tickets</Link>
              </button>
                <button className="watch-trailer" onClick={handleWatchTrailer}>
                  Watch Trailer
                </button>
              </div>
            </div>
          </section>
          <div className="detailpage">
            <p>Rating: {movie.rating}</p>
            <p>{movie.description}</p>
            <p>Genre: {movie.genre}</p>
            <div className="showtimes">
              <h3>Showtimes</h3>
              {loading ? (
                <p>Loading showtimes...</p>
              ) : showtimes.length > 0 ? (
                <ul>
                  {showtimes.map((showtime, index) => (
                    <li key={index}>
                      {showtime.date} {showtime.time} - {showtime.theater}
                    </li>
                  ))}
                </ul>
              ) : (
                <p>No showtimes available.</p>
              )}
            </div>

            {showTrailer && (
              <div className="trailer-container">
                <iframe
                  width="560"
                  height="315"
                  src={movie.trailerLink} 
                  title="YouTube video player"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            )}

            {showTrailer && (
              <div className="trailer-container">
                <iframe
                  width="560"
                  height="315"
                  src={movie.trailerLink} 
                  title="YouTube video player"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            )}
          </div>
        </div>
      ) : (
        <p>Movie not found</p>
      )}
    </div>
  );
};

export default MovieDetail;