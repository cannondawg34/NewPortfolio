import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

import Breadcrumb from './Breadcrumb';

import './Admin.css'; 
import './Breadcrumb.css';

const AddMovieForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    status: '',
    trailerLink: '',
    trailerPic: '',
    rating: '',
    genre: '',
    schedule: []
  });
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(''); // New state for error message

  const genres = [
    "Action", "Comedy", "Drama", "Horror", "Romance", "Sci-Fi", "Fantasy", "Thriller"
  ];
  
  const navigate = useNavigate();

  const handleChange = (e) => {
      const { id, value } = e.target;
      setFormData({
          ...formData,
          [id]: value
      });
  };

  // Handle for status and rating
  const handleSelectChange = (type, value) => {
    if (type === 'status') {
        setFormData({ ...formData, status: value });
    }
    if (type === 'rating') {
        setFormData({ ...formData, rating: value });
    }
  };
  

  const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);
      setErrorMessage(''); // Reset error message on each submit attempt

      try {
          const response = await fetch('http://localhost:8080/api/movies/add', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify(formData),
          });

          if (response.ok) {
              console.log('Movie added successfully');
              navigate('/admin/movies'); 
          } else {
              console.error('Error:', response.statusText);
              const errorText = await response.text(); // Get the error message from response
              setErrorMessage(`Error: ${errorText || response.statusText}`);
              setLoading(false);
          }
      } catch (error) {
          console.error('Request failed:', error);
          setErrorMessage(`Request failed: ${error.message}`);
          setLoading(false);
      }
  };

  return (
    <div className="admin-container">
      <div className="admin-sidebar">
        <Link to="/admin">
          <h2>E-Cinema Admin</h2>
        </Link>
        <nav className="admin-menu">
          <ul>
            <li><Link to="/admin/movies">Movies</Link></li>
            <li><Link to="/admin/users">Users</Link></li>
            <li><Link to="/admin/pricing">Pricing</Link></li>
            <li><Link to="/admin/promotions">Promotions</Link></li>
          </ul>
        </nav>
      </div>

      <div className="admin-content">
        <div className="admin-header">
          <p>You are logged in as <strong>Admin1</strong></p>
          <Link to="/logout">Logout</Link>
        </div>
        <div className="admin-body">
          <Breadcrumb />
          <h2>Add New Movie</h2>
          {errorMessage && <p className="error-message">{errorMessage}</p>} {/* Display error message */}
          <form onSubmit={handleSubmit}>
            <label className="form-label">
              Title:
              <input type="text" id="title" value={formData.title} onChange={handleChange} required />
            </label>
            <br />
            <label className="form-label">
              Status:
              <div className="bubble-container">
                <button
                  type="button"
                  className={`bubble ${formData.status === 'Now Playing' ? 'active' : ''}`}
                  onClick={() => handleSelectChange('status', 'Now Playing')}
                >
                  Now Playing
                </button>
                <button
                  type="button"
                  className={`bubble ${formData.status === 'Coming Soon' ? 'active' : ''}`}
                  onClick={() => handleSelectChange('status', 'Coming Soon')}
                >
                  Coming Soon
                </button>
              </div>
            </label>
            <br />
            <label className="form-label">
              Trailer Link:
              <input type="text" id="trailerLink" value={formData.trailerLink} onChange={handleChange} required />
            </label>
            <br />
            <label className="form-label">
              Image URL:
              <input type="text" id="trailerPic" value={formData.trailerPic} onChange={handleChange} required />
            </label>
            <br />
            <label className="form-label">
              Rating:
              <div className="bubble-container">
                <button
                  type="button"
                  className={`bubble ${formData.rating === 'G' ? 'active' : ''}`}
                  onClick={() => handleSelectChange('rating', 'G')}
                >
                  G
                </button>
                <button
                  type="button"
                  className={`bubble ${formData.rating === 'PG' ? 'active' : ''}`}
                  onClick={() => handleSelectChange('rating', 'PG')}
                >
                  PG
                </button>
                <button
                  type="button"
                  className={`bubble ${formData.rating === 'PG-13' ? 'active' : ''}`}
                  onClick={() => handleSelectChange('rating', 'PG-13')}
                >
                  PG-13
                </button>
                <button
                  type="button"
                  className={`bubble ${formData.rating === 'R' ? 'active' : ''}`}
                  onClick={() => handleSelectChange('rating', 'R')}
                >
                  R
                </button>
              </div>
            </label>
            <br />
            <label className="form-label">
              Genre:
              <select id="genre" value={formData.genre} onChange={handleChange} required>
                <option value="">Select Genre</option>
                {genres.map((genre) => (
                  <option key={genre} value={genre}>
                    {genre}
                  </option>
                ))}
              </select>
            </label>
            <br />
            <button type="submit" disabled={loading}>
              Submit
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddMovieForm;