import React from 'react';
import { Link } from 'react-router-dom';


const MovieTable = ({title, movies = [] }) => {
  const generateIdFromTitle = (title) => {
    return title.toLowerCase().replace(/\s+/g, '-'); 
  };

  return (
  <table>
    <thead>
      <tr>
        <th>Title</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {movies.map((movie, index) => (
        <tr key={index}>
          <td>{movie.title}</td>
          <td>{movie.status ? movie.status : 'N/A'}</td>
          <td>
            <button onClick={() => handleUpdate(movie.id)}>Update</button>
            <button onClick={() => handleDelete(movie.id)}>Delete</button>
            <Link to={`/admin/movies/schedule/${generateIdFromTitle(movie.title)}`}>
              <button onClick={() => handleSchedule(movie.id)}>Schedule</button>
            </Link>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
  );
};

const handleUpdate = (id) => {
  console.log(`Updating movie with ID: ${id}`);
};

const handleDelete = (id) => {
  console.log(`Deleting movie with ID: ${id}`);
};

const handleSchedule = (id) => {
  console.log(`Scheduling movie with ID: ${id}`);
};

export default MovieTable;