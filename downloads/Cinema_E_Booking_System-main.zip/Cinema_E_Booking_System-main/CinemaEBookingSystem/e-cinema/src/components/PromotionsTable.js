import React, { useState, useEffect } from 'react';

const PromotionsTable = ({ onDelete }) => {
  const [promotions, setPromotions] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/api/users/promotions')
      .then((response) => response.json())
      .then((data) => {
        setPromotions(data);
      })
      .catch((error) => console.error('Error fetching promotions:', error));
  }, []);

  return (
    <div>
      <h1>Promotions</h1>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Percent</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {promotions.length === 0 ? (
            <tr>
              <td colSpan="3">No promotions available</td>
            </tr>
          ) : (
            promotions.map((promotion, index) => (
              <tr key={index}>
                <td>{promotion.name}</td>
                <td>{promotion.percent}%</td>
                <td>
                  <button onClick={() => onDelete(promotion.name)}>Delete</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default PromotionsTable;
