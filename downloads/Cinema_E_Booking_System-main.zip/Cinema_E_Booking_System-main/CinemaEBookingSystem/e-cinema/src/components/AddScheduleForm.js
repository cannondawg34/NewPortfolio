import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';

import Breadcrumb from './Breadcrumb';

import './Admin.css'; 
import './Breadcrumb.css';

const AddScheduleForm = ({ movies }) => {
  const { title } = useParams();
  const [scheduleData, setScheduleData] = useState({ date: '', time: '', theater: '' });
  const [formData, setFormData] = useState({ schedule: [] });
  const [loading, setLoading] = useState(false);
  const [moviesLoading, setMoviesLoading] = useState(!movies.length); // Add loading state for movies
  const [errorMessage, setErrorMessage] = useState(''); // New state for error message
  const [availableTimes, setAvailableTimes] = useState([]);
  const [isFinishEnabled, setIsFinishEnabled] = useState(false); // New state for Finish button

  const theaters = ['Theater 1', 'Theater 2', 'Theater 3'];
  
  const navigate = useNavigate();

  // Check if movies are still loading
  useEffect(() => {
    if (movies.length > 0) {
      setMoviesLoading(false); 
    }
  }, [movies]);

  const movie = movies.find((movie) => 
    movie.title.toLowerCase().replace(/\s+/g, '-') === title
  );
  console.log(movie);

  useEffect(() => {
    if (!movie && !moviesLoading) {
      setErrorMessage("Movie not found. Returning to Movies page...");
      const timer = setTimeout(() => {
        navigate('/admin/movies');
      }, 3000); // 3 seconds delay
  
      return () => clearTimeout(timer);
    }
  }, [movie, moviesLoading, navigate]);

  useEffect(() => {
    if (!movie) return;

    const fetchMovieSchedule = async () => {
      setLoading(true);
      setErrorMessage('');
  
      try {
        const response = await fetch(`http://localhost:8080/api/movies/schedule/${movie.title}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        if (response.ok) {
          const data = await response.json();
          
          // Assuming the data.schedule is an array of "YYYY-MM-DD HH:MM" formatted strings
          const parsedSchedule = data.schedule.map((datetime) => {
            // Split the datetime string into date, time, and theater parts
            const [dateTimePart, theater] = datetime.split('$');
            const [date, time] = dateTimePart.split(' ');  // ["YYYY-MM-DD", "HH:MM"]
            
            console.log('dateTimePart:', dateTimePart); // This will log the "YYYY-MM-DD HH:MM" part
            console.log('theater:', theater);

            return { date: date.trim(), time: time.trim(), theater: theater.trim() }; // Return as an object with separate date and time
          });
  
          setFormData({ schedule: parsedSchedule }); // Update the state with parsed date and time
          setIsFinishEnabled(parsedSchedule.length > 0 || formData.schedule.length === 0); // Enable Finish if schedule exists or is empty
        } else {
          setErrorMessage('Error fetching schedule');
        }
      } catch (error) {
        setErrorMessage(`Request failed: ${error.message}`);
      }
      setLoading(false);
    };
  
    fetchMovieSchedule();
  }, [movie, formData.schedule.length]);

  useEffect(() => {
    setIsFinishEnabled(formData.schedule.length >= 0 && !loading); // Enable Finish only if there's a schedule and no loading
  }, [formData.schedule.length, loading]);

  const generateTimes = () => {
    return ['08:00', '11:00', '14:00', '17:00', '20:00'];
  };

  /*
  const isTimeAvailable = (date, time, theater) => {
    const defaultDuration = 120;
    const newStart = new Date(`${date}T${time}`);
    
    return !formData.schedule.some((existing) => {
      if (existing.theater !== theater) return false; 
      
      const existingStart = new Date(`${existing.date}T${existing.time}`);
      
      const movieDuration = movie?.duration || defaultDuration;
      const existingEnd = new Date(existingStart.getTime() + movieDuration * 60 * 1000 + 30 * 60 * 1000);
      
      return existingStart <= newStart && newStart < existingEnd;
    });
  };
  */

  useEffect(() => {
    const currentTime = new Date();

    const isPastTime = (selectedTime) => {
      const [hours, minutes] = selectedTime.split(':');
      const selectedDate = new Date(scheduleData.date);
      selectedDate.setHours(hours, minutes, 0, 0); 
      return selectedDate < currentTime; 
    };

    if (scheduleData.date && scheduleData.theater) {
      const times = generateTimes();
      const filteredTimes = times.filter(time => 
        !formData.schedule.some(
          entry => entry.date === scheduleData.date && entry.time === time && entry.theater === scheduleData.theater
        ) && !isPastTime(time) 
      );
      setAvailableTimes(filteredTimes);
    }
  }, [scheduleData.date, scheduleData.theater, formData.schedule]);

  
  const handleScheduleChange = (e) => {
    const { id, value } = e.target;
    setScheduleData({
      ...scheduleData,
      [id]: value
    });
  };

  const addSchedule = async () => {
    if (scheduleData.date && scheduleData.time && scheduleData.theater) {
      setLoading(true);
      setErrorMessage('');

      try {
        const response = await fetch('http://localhost:8080/api/movies/schedule', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            movieId: movie.id,
            date: scheduleData.date,
            time: scheduleData.time,
            theaterName: scheduleData.theater
          }),
        });

        if (response.ok) {
          console.log('Showing added successfully');
          setFormData(prevState => ({
            ...prevState,
            schedule: [...prevState.schedule, { ...scheduleData}]
          }));
          setScheduleData({ date: '', time: '', theater: '' });
          setIsFinishEnabled(formData.schedule.length > 0 && !loading); // Enable Finish only if there is a schedule and no loading
        } else {
          const errorText = await response.text();
          setErrorMessage(`Error: ${errorText || response.statusText}`);
        }
      } catch (error) {
        setErrorMessage(`Request failed: ${error.message}`);
      }
      
      setLoading(false);
    } else {
      setErrorMessage("Please fill out all of the required fields.");
      return;
    } // if

  };
  
  const deleteSchedule = async (index) => {
    const showingToDelete = formData.schedule[index];
    setLoading(true);
    setErrorMessage('');

    try {
      const response = await fetch(`http://localhost:8080/api/movies/schedule`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          movieId: movie.id,
          date: showingToDelete.date,
          time: showingToDelete.time,
          theater: showingToDelete.theater
        }),
      });
  
      if (response.ok) {
        console.log('Showing deleted successfully');
        setFormData(prevState => ({
          ...prevState,
          schedule: prevState.schedule.filter((_, i) => i !== index)
        }));
        setIsFinishEnabled(formData.schedule.length >= 0 && !loading); // Enable Finish only if there's a schedule and no loading
      } else {
        const errorText = await response.text();
        setErrorMessage(`Error: ${errorText || response.statusText}`);
      }
    } catch (error) {
      setErrorMessage(`Request failed: ${error.message}`);
    }

    setLoading(false);
  };

  const handleFinish = () => {
    navigate('/admin/movies');
  };

  return (
    <div className="admin-container">
      <div className="admin-sidebar">
        <Link to="/admin">
          <h2>E-Cinema Admin</h2>
        </Link>
        <nav className="admin-menu">
          <ul>
            <li><Link to="/admin/movies">Movies</Link></li>
            <li><Link to="/admin/users">Users</Link></li>
            <li><Link to="/admin/pricing">Pricing</Link></li>
            <li><Link to="/admin/promotions">Promotions</Link></li>
          </ul>
        </nav>
      </div>

      <div className="admin-content">
        <div className="admin-header">
          <p>You are logged in as <strong>Admin1</strong></p>
          <Link to="/logout">Logout</Link>
        </div>
        <div className="admin-body">
          <Breadcrumb />
          {movie ? (
            <>
              <h2>Schedule Showing for '{movie.title}'</h2>
              {errorMessage && <p className="error-message">{errorMessage}</p>}
              <form>
                <label className="form-label">
                  Date:
                  <input type="date" id="date" value={scheduleData.date} onChange={handleScheduleChange} required />
                </label>
                <br />
                <label className="form-label">
                  Theater:
                  <select id="theater" value={scheduleData.theater} onChange={handleScheduleChange} required>
                    <option value="" disabled>Select Theater</option>
                    {theaters.map((theater, index) => (
                      <option key={index} value={theater}>{theater}</option>
                    ))}
                  </select>
                </label>
                <br />
                <label className="form-label">
                  Time:
                  <select id="time" value={scheduleData.time} onChange={handleScheduleChange} required style={{ color: 'black' }}>
                    <option value="">Select time</option>
                    {availableTimes.map(time => (
                      <option key={time} value={time}>{time}</option>
                    ))}
                  </select>
                </label>
                <br />
                <button type="button" onClick={addSchedule} disabled={loading}>Add Showing</button>
                <br />
                <div>
                  <h4>Scheduled Times:</h4>
                  <ul>
                    {formData.schedule.map((entry, index) => (
                      <li key={index}>
                        <span className="schedule-segment">{entry.date}</span>
                        <span className="schedule-segment">{entry.time}</span>
                        <span className="schedule-segment">{entry.theater}</span>
                        <button type="button" onClick={() => deleteSchedule(index)} disabled={loading}>Delete</button>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <br />
                <button type="button" onClick={handleFinish} disabled={!isFinishEnabled}>
                  Finish
                </button>
              </form>
            </>
          ) : (
            <p>Loading movie information...</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddScheduleForm;