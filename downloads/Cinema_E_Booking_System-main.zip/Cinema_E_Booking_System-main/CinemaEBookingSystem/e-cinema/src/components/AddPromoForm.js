import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

import Breadcrumb from './Breadcrumb';

import './Admin.css'; 
import './Breadcrumb.css';

const AddPromoForm = () => {
  const [code, setCode] = useState('');
  const [percent, setPercent] = useState('');
  const [error, setError] = useState(null); // To store any errors from the backend
  const [success, setSuccess] = useState(false); // To show success message
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    // Create the promotion object
    const promotionData = {
      promotion: code,
      percent: parseInt(percent, 10), // Ensure percent is an integer
    };

    try {
      // Send the request to the backend
      const response = await fetch('http://localhost:8080/api/users/newpromotion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(promotionData),
      });

      // Handle the response from the backend
      if (!response.ok) {
        throw new Error('Failed to create promotion');
      }

      const result = await response.json();
      setSuccess(true);
      setError(null); // Clear any previous errors

      // You can log the result or handle it further if needed
      console.log('Promotion created successfully:', result);
      navigate('/admin');
    } catch (error) {
      setError(error.message);
      setSuccess(false);
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="admin-container">
      <div className="admin-sidebar">
        <Link to="/admin">
          <h2>E-Cinema Admin</h2>
        </Link>
        <nav className="admin-menu">
          <ul>
            <li><Link to="/admin/movies">Movies</Link></li>
            <li><Link to="/admin/users">Users</Link></li>
            <li><Link to="/admin/pricing">Pricing</Link></li>
            <li><Link to="/admin/promotions">Promotions</Link></li>
          </ul>
        </nav>
      </div>

      <div className="admin-content">
        <div className="admin-header">
          <p>You are logged in as <strong>Admin1</strong></p>
          <Link to="/logout">Logout</Link>
        </div>
        <div className="admin-body">
          <Breadcrumb />
          <h2>Add New Promotion</h2>

          {/* Display success or error messages */}
          {success && <p className="success-message">Promotion added successfully!</p>}
          {error && <p className="error-message">Error: {error}</p>}

          <form onSubmit={handleSubmit}>
            <label className="form-label">
              Code:
              <input 
                type="text" 
                value={code} 
                onChange={(e) => setCode(e.target.value)} 
                required 
              />
            </label>
            <br />
            <label className="form-label">
              Percent:
              <input 
                type="number" 
                value={percent} 
                onChange={(e) => setPercent(e.target.value)} 
                required 
                min="1" 
                max="100" 
              />
            </label>
            <br />
            <button type="submit" disabled={loading}>Submit</button>
          </form>
          {loading && <p className="loading-text">Loading...</p>}
        </div>
      </div>
    </div>
  );
};

export default AddPromoForm;
