package com.yourgroup.cinemaebooking.controllers;

import java.util.*;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.yourgroup.cinemaebooking.accessors.CardAccess;
import com.yourgroup.cinemaebooking.accessors.UserAccess;
import com.yourgroup.cinemaebooking.objects.PaymentCard;
import com.yourgroup.cinemaebooking.objects.User;
import com.yourgroup.cinemaebooking.objects.Promotion;
import com.yourgroup.cinemaebooking.requests.PasswordResetRequest;
import com.yourgroup.cinemaebooking.EmailSenderService;
import com.yourgroup.cinemaebooking.utilities.PasswordUtility;
import com.yourgroup.cinemaebooking.DatabaseObjects.CardDBO;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/users")
public class UserController {

    private static final int MIN_CODE = 100000;
    private static final int MAX_CODE = 999999;

    @Autowired
    private EmailSenderService emailSenderService;

    @PostMapping("/verify-code-registration")
    public ResponseEntity<String> verifyRegistrationCode(@RequestBody VerificationRequest request) {

        // Retrieve the stored verification code for the user by email
        int storedCode = UserAccess.getVerificationCode(request.getEmail());

        if ((storedCode != -1) && (storedCode == Integer.parseInt(request.getCode()))) {
            // Verification successful
            UserAccess.verifyUser(request.getEmail());
            return ResponseEntity.ok("Verification successful");
        } // if
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verification failed");
    } // verifyRegistrationCode

    static class VerificationRequest {
        private String email;
        private String code;

        // Getters and setters
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }

        public String getCode() { return code; }
        public void setCode(String code) { this.code = code; }
    } // VerificationRequest

    @PostMapping()
    public ResponseEntity<Map<String, String>> createUser(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();
        int check = UserAccess.checkEmailAndPhone(user.getEmail(), user.getPhone());
  
        if (check == 0) {
            user.hashPassword();
            user.fixDate();
            user.encryptCard();
            int verificationCode = generateRandomCode();

            if (sendVerificationEmail(user.getEmail(), verificationCode)) {
                user.setVerified(false);
                user.setVerifCode(verificationCode);
                UserAccess.saveUser(user);
                response.put("message", "User created successfully");
                return ResponseEntity.ok(response);
            } else {
                response.put("message", "Failed to send verification email");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            } // if

        } else {
            response.put("message", check == 1 ? "Email or phone already exists" : "Error");
            return ResponseEntity.status(check == 1 ? HttpStatus.CONFLICT : HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        } // if

    } // createUser

    @PostMapping("/profile")
    public ResponseEntity<User> returnProfile(@RequestBody Map<String, String> payload) {
        // Fetch user from the database using the email
        User user = UserAccess.findByEmail(payload.get("email"));
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
    } // returnProfile

    @PostMapping("/edit")
    public ResponseEntity<Map<String, String>> editUser(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();

        try {
            // Ensure password is hashed if changed
            if (user.getPassword() != null) {
                user.setPassword(PasswordUtility.hashPass(user.getPassword()));
            } // if

            // Update user in the database
            UserAccess.updateUser(user);

            // Send confirmation email
            emailSenderService.sendEmail(user.getEmail(), "Account Updated", "Your account has been updated successfully!");
            
            response.put("message", "User updated successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("message", "An error occurred: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        } // try

    } // editUser
  
    @PostMapping("/changePassword")
    public ResponseEntity<Map<String, String>> changePassword(@RequestBody Map<String, String> payload) {
        Map<String, String> response = new HashMap<>(); 

        // Validate old password
        if (!validateUser(payload.get("email"), payload.get("oldPassword"))) {
            return ResponseEntity.status(401).body(Map.of("success", "false", "message", "Old password is incorrect. Try again."));
        } // if

        // If old password is correct, update the new password
        User user = UserAccess.findByEmail(payload.get("email"));
        if (user != null) {
            user.setPassword(payload.get("newPassword"));
            user.hashPassword(); // Hash the new password
            UserAccess.updatePassword(user); // Update user in the database
            emailSenderService.sendEmail(user.getEmail(), "Password changed", "Your password has been changed.");
            response.put("success", "true");
            response.put("message", "Password changed successfully!");
            return ResponseEntity.ok(response);
        } else {
            response.put("success", "false");
            response.put("message", "User not found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } // if

    } // changePassword

    @PostMapping("/send-code")
    public ResponseEntity<Map<String, String>> forgotPassword(@RequestBody Map<String, String> payload) {
        return sendVerificationCode(payload.get("email"))
                ? ResponseEntity.ok(Map.of("message", "Verification code sent successfully."))
                : ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("message", "Failed to send verification code."));

    } // forgotPassword

    @PostMapping("/verify-code-reset")
    public ResponseEntity<Map<String, String>> verifyResetCode(@RequestBody VerificationRequest request) {
        Map<String, String> response = new HashMap<>();

        String email = request.getEmail();
        String code = request.getCode();
        int actualCode = UserAccess.getResetCode(email);

        if (Integer.parseInt(code) == actualCode) {
            response.put("message", "Code verified successfully");
            return ResponseEntity.ok(response);
        } else {
            response.put("message", "Code NOT verified");
            return ResponseEntity.status(404).body(response);
        } // if

    } // verifyResetCode

    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPasswordPage(@RequestBody PasswordResetRequest request) {
        Map<String, String> response = new HashMap<>();
        String newPassHashed = PasswordUtility.hashPass(request.getNewPassword());
        if (UserAccess.updatePassword(request.getEmail(), newPassHashed)) {
            response.put("message", "Password updated successfully");
            return ResponseEntity.ok(response);
        } else {
            response.put("message", "Password NOT updated successfully");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        } // if
        
    } // resetPasswordPage

    @PostMapping("/cards")
    public ResponseEntity<List<CardDBO>> getCards(@RequestBody Map<String, String> payload) {
        List<CardDBO> cards = CardAccess.getCardDBOsByEmail(payload.get("email"));
        
        if (cards != null) {
            return ResponseEntity.ok(cards);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.emptyList());
        } // if
    } // getCards

    @PostMapping("/editcards")
    public ResponseEntity<Map<String, String>> editCards(@RequestBody EditCardsRequest request) {
        String email = request.getEmail();
        List<CardDBO> newCards = request.getCards();
        System.out.println("Received cards before filtering: " + newCards);

        // Filter out invalid CardDBOs
        List<CardDBO> validCards = newCards.stream()
            .filter(card -> card.getCardNumber() != null && !card.getCardNumber().trim().isEmpty()
                        && card.getExpirationDate() != null && !card.getExpirationDate().trim().isEmpty()
                        && card.getCardType() != null && !card.getCardType().trim().isEmpty()
                        && card.getCVV() != null && !card.getCVV().trim().isEmpty())
            .toList();
        System.out.println("Received cards after filtering: " + validCards);

        // Delete old cards and insert new cards
        int deleted = CardAccess.deleteCardsByEmail(email);
        System.out.println("Num cards deleted: " + deleted);
        if (deleted >= 0) {
            boolean allInserted = validCards.stream().allMatch(card -> CardAccess.insertCardDBO(card, email));
            if (allInserted) {
                return ResponseEntity.ok(Map.of("message", "Cards processed successfully"));
            }
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("message", "Failed to process cards"));
    }

    private boolean sendVerificationEmail(String email, int code) {
        String body = "You have created a new account with e-cinema!\n" +
                      "Your 6-digit verification code is: " + code + "\n" +
                      "(If this wasn't you, ignore this email)";
        try {
            emailSenderService.sendEmail(email, "E-Cinema User Created", body);
            return true;
        } catch (Exception e) {
            System.err.println("Failed to send email: " + e.getMessage());
            return false;
        } // try
    } // sendVerificationEmail

    private boolean sendVerificationCode(String email) {
        int randomCode = generateRandomCode();

        // store code first
        if (!UserAccess.storeResetCode(email, randomCode)) {
            return false;
        } // if

        String body = "Your password reset code is: " + randomCode;
        emailSenderService.sendEmail(email, "Reset Password Code", body);

        return true;

    } // sendVerificationCode

    private boolean validateUser(String email, String password) {
        if (UserAccess.checkForEmail(email) == 1) {
            return PasswordUtility.verifyPass(password, UserAccess.getHashedPass(email));
        } // if
        return false;
    } // validateUser

    @PostMapping("/newpromotion")
    public ResponseEntity<Map<String, String>> newPromotion(@RequestBody PromotionRequest request) {
        Map<String, String> response = new HashMap<>();
        try {
            UserAccess.createPromotion(request.getPromotion(), request.getPercent());
            List<String> promotionUser = UserAccess.getPromotionUsers();
            for (int i = 0; i < promotionUser.size(); i++) {
                emailSenderService.sendEmail(promotionUser.get(i), "New Promotion: " + request.getPromotion(),
                        "There is a new promotion available to you! Use " + request.getPromotion() + " for " + request.getPercent() + "% off your next purchase!");
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("message", "An error occurred: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        } // try/catch
    } // newpromotion

    public static class PromotionRequest {
        private String promotion;
        private int percent;
        public String getPromotion() {
            return promotion;
        } // getPromotion
        public void setPromotion(String promotion) {
            this.promotion = promotion;
        } // setPromotion
        public int getPercent() {
            return percent;
        } // getPercent
        public void setPercent(int percent) {
            this.percent = percent;
        } // setPercent
    } // promotionrequest
    @GetMapping("/promotions")
    public ResponseEntity<List<Promotion>> getAllPromotions() {
        List<Promotion> promotions = UserAccess.getAllPromotions();
        
        if (promotions.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(promotions);
        } else {
            return ResponseEntity.ok(promotions);
        } // else
    } // promotions
    

    private int generateRandomCode() {
        return new Random().nextInt((MAX_CODE - MIN_CODE) + 1) + MIN_CODE;
    } // generateRandomCode
    

    public static class EditCardsRequest {
        private String email;
        private List<CardDBO> cards;

        // Getters and Setters
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }

        public List<CardDBO> getCards() { return cards; }
        public void setCards(List<CardDBO> cards) { this.cards = cards; }
    } // EditCardsRequest

} // UserController

