package com.yourgroup.cinemaebooking.DatabaseObjects;

public class CardDBO {
    private int cardId;
    private String cardNumber;
    private String expirationDate;
    private int userId;
    private String cardType;
    private String cvv;

    public CardDBO() {
        this.cardId = -1;
        this.cardNumber = null;
        this.expirationDate = null;
        this.userId = -1;
        this.cardType = null;
        this.cvv = null;
    } // CardDBO (default constructor)

    public CardDBO(int c, String num, String e, int u, String type, String cvv) {
        this.cardId = c;
        this.cardNumber = num;
        this.expirationDate = e;
        this.userId = u;
        this.cardType = type;
        this.cvv = cvv;
    } // CardDBO

    @Override
    public String toString() {
        return "CardDBO {" +
              "cardId=" + cardId +
              ", cardNumber='" + cardNumber + '\'' +
              ", expirationDate='" + expirationDate + '\'' +
              ", cardType='" + cardType + '\'' +
              ", cvv='" + cvv + '\'' +
              ", userId=" + userId +
              '}';
    } // toString

    // Getters
    public int getCardId() {
        return cardId;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public int getUserId() {
        return userId;
    }

    public String getCardType() {
        return cardType;
    }

    public String getCVV() {
        return cvv;
    }

    // Setters
    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public void setCVV(String cvv) {
        this.cvv = cvv;
    }
} // CardDBO
