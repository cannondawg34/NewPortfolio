package com.yourgroup.cinemaebooking.DTOs;

public class SeatAgeDTO {
    private String seat;
    private String age;

    public String getSeat() {
        return this.seat;
    }

    public void setSeat(String newSeat) {
        this.seat = newSeat;
    }

    public String getAge() {
        return this.age;
    }

    public void setAge(String newAge) {
        this.age = newAge;
    }

} // SeatAgeDTO
