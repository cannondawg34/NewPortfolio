package com.yourgroup.cinemaebooking.accessors;

import java.sql.*;
import java.util.*;

import com.yourgroup.cinemaebooking.DatabaseObjects.*;

public class PromotionAccess {
    private static final String url = "jdbc:mysql://cinema-booking.cfysagqmu79l.us-east-2.rds.amazonaws.com:3306/cinema_booking";
    private static final String username = "cameran";
    private static final String password = "Candawg34!";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    } // getConnection

    public static double getPromoPercentage(String promoCode) {
        String sql = "SELECT percentage FROM promotions WHERE name=?";
        System.out.println(sql);

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
                                
            ps.setString(1, promoCode);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("percentage");
                } else {
                    return 0.0;
                }
            } // try

        } catch (SQLException e) { // Error getting promo percentage
            e.printStackTrace();
            return -1.0;
        } // try
    } // getPromoPercentage
    
} // PromotionAccess
