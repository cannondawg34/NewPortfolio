package com.yourgroup.cinemaebooking.DatabaseObjects;

import com.yourgroup.cinemaebooking.accessors.*;

public class ReservationDBO {
    private int bookingId;
    private String userEmail;
    private int seatId;
    private int age;
    private boolean isCheckedOut;
    private boolean emailSent;

    public ReservationDBO(int b, String e, int s, int a, int i, int j) {
        this.bookingId = b;
        this.userEmail = e;
        this.seatId = s;
        this.age = a;
        if (i == 0) {
            this.isCheckedOut = false;
        } else {
            this.isCheckedOut = true;
        } // if
        if (j == 0) {
            this.emailSent = false;
        } else {
            this.emailSent = true;
        } // if
    } // constructor

    public int getBookingId() {
        return this.bookingId;
    }

    public void setBookingId(int i) {
        this.bookingId = i;
    }

    public String getUserEmail() {
        return this.userEmail;
    }

    public void setUserEmail(String s) {
        this.userEmail = s;
    }

    public int getSeatId() {
        return this.seatId;
    }

    public void setSeat(int s) {
        this.seatId = s;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int i) {
        this.age = i;
    }

    public boolean getIsCheckedOut() {
        return this.isCheckedOut;
    }

    public void setIsCheckedOut(boolean b) {
        this.isCheckedOut = b;
    }

    public boolean getEmailSent() {
        return this.emailSent;
    }

    public void setEmailSent(boolean b) {
        this.emailSent = b;
    }

    public SeatDBO getSeatDBO() {
        return SeatAccess.getSeat(this.seatId);
    } // getSeatDBO

} // ReservationDBDTO
