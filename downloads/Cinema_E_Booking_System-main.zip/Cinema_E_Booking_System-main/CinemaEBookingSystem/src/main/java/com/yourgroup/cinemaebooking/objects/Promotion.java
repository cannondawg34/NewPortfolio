package com.yourgroup.cinemaebooking.objects;

public class Promotion {
  private String name;
  private int percent;

  public Promotion(String name, int percent) {
      this.name = name;
      this.percent = percent;
  } // Promotion constructor

  public String getName() {
      return name;
  } // getName

  public void setName(String name) {
      this.name = name;
  } // setName

  public int getPercent() {
      return percent;
  } // getPercent

  public void setPercent(int percent) {
      this.percent = percent;
  } // setPercent
} // Promotion