package com.yourgroup.cinemaebooking.DatabaseObjects;

import com.yourgroup.cinemaebooking.accessors.*;

public class SeatDBO {
    private int seatId;
    private int showingId;
    private String seatLabel;

    public SeatDBO(int i, int s, String l) {
        this.seatId = i;
        this.showingId = s;
        this.seatLabel = l;
    } // constructor

    public int getSeatId() {
        return this.seatId;
    }

    public void setSeatId(int i) {
        this.seatId = i;
    }

    public int getShowingId() {
        return this.showingId;
    }

    public void setShowing(int s) {
        this.showingId = s;
    }

    public String getSeatLabel() {
        return this.seatLabel;
    }

    public void setSeatLabel(String s) {
        this.seatLabel = s;
    }

    public MovieScheduleDBO getMovieScheduleDBO() {
        return ScheduleAccess.getSchedule(this.showingId);
    } // getMovieScheduleDBO

} // SeatDBDTO
