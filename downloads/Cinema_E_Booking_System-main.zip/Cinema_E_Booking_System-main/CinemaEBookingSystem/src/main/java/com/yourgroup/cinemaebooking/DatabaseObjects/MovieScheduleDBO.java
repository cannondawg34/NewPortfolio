package com.yourgroup.cinemaebooking.DatabaseObjects;

import com.yourgroup.cinemaebooking.accessors.*;

public class MovieScheduleDBO {
    private int movieScheduleId;
    private int movieId;
    private String dateTime;
    private String theaterName;

    public MovieScheduleDBO(int id, int m, String d, String t) {
        this.movieScheduleId = id;
        this.movieId = m;
        this.dateTime = d;
        this.theaterName = t;
    } // constructor

    // Getters and Setters
    public int getMovieScheduleId() {
        return movieScheduleId;
    }

    public void setMovieScheduleId(int movieScheduleId) {
        this.movieScheduleId = movieScheduleId;
    }

    public int getMovieId() {
        return this.movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getTheaterName() {
        return theaterName;
    }

    public void setTheaterName(String theaterName) {
        this.theaterName = theaterName;
    }

    public MovieDBO getMovieDBO() {
        return MovieAccess.getMovie(this.movieId);
    }

} // MovieScheduleDBDTO
