package com.yourgroup.cinemaebooking.accessors;

import java.sql.*;
import java.util.*;

import com.yourgroup.cinemaebooking.objects.User;
import com.yourgroup.cinemaebooking.objects.Promotion;

public class UserAccess {

    private static final String url = "jdbc:mysql://cinema-booking.cfysagqmu79l.us-east-2.rds.amazonaws.com:3306/cinema_booking";
    private static final String username = "cameran";
    private static final String password = "Candawg34!";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    } // getConnection

    private static int executeUpdate(String sql, Object... params) {
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try
    } // executeUpdate

    public static int updateUser(User user) {
        String sql = "UPDATE users SET full_name = ?, phone = ?, street = ?, city = ?, state = ?, zip = ?, promotional_opt_in = ? WHERE email = ?";
        return executeUpdate(sql, user.getName(), user.getPhone(), user.getStreet(), user.getCity(), user.getState(), user.getZip(), user.getPromotion(), user.getEmail());
    } // updateUser

    public static int updatePassword(User user) {
        String sql = "UPDATE users SET full_name = ?, phone = ?, street = ?, city = ?, state = ?, zip = ?, promotional_opt_in = ?, password = ? WHERE email = ?";
        return executeUpdate(sql, user.getName(), user.getPhone(), user.getStreet(), user.getCity(), user.getState(), user.getZip(), user.getPromotion(), user.getPassword(), user.getEmail());
    } // updatePassword

    public static int getVerificationCode(String email) {
        String sql = "SELECT verifCode FROM users WHERE email = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("verifCode");
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
        } // try
        return -1;
    } // getVerificationCode

    public static int setVerificationCode(String email, int code) {
        String sql = "UPDATE users SET verifCode = ? WHERE email = ?";
        return executeUpdate(sql, code, email);
    } // setVerificationCode

    public static int verifyUser(String email) {
        String sql = "UPDATE users SET verified = 1 WHERE email = ?";
        return executeUpdate(sql, email);
    } // verifyUser

    public static int isVerified(String email) {
        String sql = "SELECT verified FROM users WHERE email = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("verified");
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
        } // try
        return -1;

    } // isVerified

    public static int saveUser(User user) {
        String sql = "INSERT INTO users (full_name, email, password, phone, street, city, state, zip, role, promotional_opt_in, verified, verifCode) VALUES (";
        sql += (user.toString() + ")");
        Connection con = null;
        Statement st = null;
        ResultSet generatedKeys = null;

        try {
            con = DriverManager.getConnection(url, username, password);
            generatedKeys = null;
            if (con == null) {
                return -1;            
            } // if

            st = con.createStatement();
            if (st == null) {
                return -1;
            } // if

            st.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);

            if (!(user.cardToString().isEmpty())) {
                generatedKeys = st.getGeneratedKeys();
                int userId = 0;
                if (generatedKeys.next()) {
                    userId = generatedKeys.getInt(1);
                } // if
                  
                String cardSql = "INSERT INTO cards (card_type, card_number, expiration_date, cvv, user_id) VALUES (";
                cardSql += user.cardToString();
                cardSql += "'" + userId + "'";
                cardSql += ")";

                st = con.createStatement();
                if (st == null) {
                        return -1;
                } // if

                System.out.println("Adding card to database...");
                st.executeUpdate(cardSql);
                System.out.println("Card added to database!");

            } // if
          
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } finally {
            // Close resources in reverse order of their opening
            try {
                if (generatedKeys != null) generatedKeys.close();
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();  // Handle any exception during closing
            }
        } // try

        return 0;
    } // saveUser

    public static int checkEmailAndPhone(String email, String phone) {
        String sql = "SELECT 1 FROM users WHERE email = ?";
        try (Connection con = getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return 1;
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try

        sql = "SELECT 1 FROM users WHERE phone = ?";
        try (Connection con = getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, phone);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return 1;
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try

        return 0;
    } // checkEmailAndPhone

    public static int checkForEmail(String email) {
        String sql = "SELECT 1 FROM users WHERE email = ?";
        try (Connection con = getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return 1;
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try
        return 0;
    } // checkForEmail

    public static User findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ?"; 
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setName(rs.getString("full_name"));
                    user.setEmail(rs.getString("email"));
                    user.setPhone(rs.getString("phone"));
                    user.setStreet(rs.getString("street"));
                    user.setCity(rs.getString("city"));
                    user.setState(rs.getString("state"));
                    user.setZip(rs.getString("zip"));
                    user.setPromotion(rs.getBoolean("promotional_opt_in"));
                    user.setVerified(rs.getBoolean("verified"));
                    user.setVerifCode(rs.getInt("verifCode"));
                    return user;
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
        } // try
        return null;
    } // findByEmail

    public static String getHashedPass(String email) {
        String sql = "SELECT password FROM users WHERE email = ?";
        try (Connection con = getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("password");
                } // if
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
        } // try
        return null;
    } // getHashedPass

    public static boolean storeResetCode(String email, int code) {
        String sql = "UPDATE users SET reset_code = ? WHERE email = ?";
        
        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, code);
            ps.setString(2, email);

            // Return true if the update affected one or more rows (i.e., the reset code was successfully stored)
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurs
        } // try

    } // storeResetCode

    public static int getResetCode(String email) {
        String sql = "SELECT resetCode FROM users WHERE email = '";
        sql += email;
        sql += "';";
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = DriverManager.getConnection(url, username, password);
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            rs.next();
            int resetCode = rs.getInt("resetCode");
            return resetCode;
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } finally {
            // Close resources in reverse order of their opening
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();  // Handle any exception during closing
            }
        } // try

    } // getResetCode

    public static boolean updatePassword(String email, String newPassword) {
        String sql = "UPDATE users SET password = '";
        sql += newPassword;
        sql += "' WHERE email = '";
        sql += email;
        sql += "';";
        Connection con = null;
        PreparedStatement ps = null;
        try {
            con = DriverManager.getConnection(url, username, password);
            ps = con.prepareStatement(sql);
            if (ps.executeUpdate() == 0) {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Close resources in reverse order of their opening
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();  // Handle any exception during closing
            }
        } // try

        return true;

    } // updatePassword

    public static List<String> getPromotionUsers() {
        List<String> promotionUsers = new ArrayList<>();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection(url, username, password);
            String query = "SELECT email FROM users WHERE promotional_opt_in = true";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                String email = rs.getString("email");
                promotionUsers.add(email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources in reverse order of their opening
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();  // Handle any exception during closing
            }
        } // try

        return promotionUsers;
    } // getPromotionUsers

    public static void createPromotion(String name, int percent) {
        String sql = "INSERT INTO promotions (name, percentage) VALUES (?, ?)";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setInt(2, percent);
            ps.executeUpdate();
            System.out.println("success!");
        } catch (SQLException e) {
            e.printStackTrace(); // error
        } // try
    } // createPromotion

    public static List<Promotion> getAllPromotions() {
        List<Promotion> promotions = new ArrayList<>();
        String sql = "SELECT name, percentage FROM promotions";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String name = rs.getString("name");
                int percentage = rs.getInt("percentage");
                promotions.add(new Promotion(name, percentage));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // catch
        return promotions;
    } // getAllPromotions

    public static int isAdmin(String email) {
        String sql = "SELECT isAdmin FROM users WHERE email=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("isAdmin");
                } // if
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try
        return -1;
    } // isAdmin
    

} // UserAccess