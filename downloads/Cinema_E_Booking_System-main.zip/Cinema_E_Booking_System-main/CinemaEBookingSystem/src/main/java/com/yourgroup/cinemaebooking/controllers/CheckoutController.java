package com.yourgroup.cinemaebooking.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import com.yourgroup.cinemaebooking.accessors.PromotionAccess;
import com.yourgroup.cinemaebooking.accessors.ReservationAccess;
import com.yourgroup.cinemaebooking.accessors.SeatAccess;
import com.yourgroup.cinemaebooking.accessors.PromotionAccess;

import com.yourgroup.cinemaebooking.DatabaseObjects.ReservationDBO;
import com.yourgroup.cinemaebooking.DatabaseObjects.SeatDBO;
import com.yourgroup.cinemaebooking.EmailSenderService; // Make sure this import exists

import java.util.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/checkout")
public class CheckoutController {

    @Autowired
    private EmailSenderService emailSenderService; // Inject EmailSenderService

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> getBookingSummary(@RequestParam String email) {
        Map<String, Object> summary = new HashMap<>();
        double totalPrice = 0.0;

        // Fetch user reservations that have not been checked out
        List<ReservationDBO> reservations = ReservationAccess.getNotCheckedOutBookingsByEmail(email);

        if (reservations == null || reservations.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("message", "No pending reservations found for this email."));
        }

        // Use a list to hold all details
        List<Map<String, Object>> seatsDetails = new ArrayList<>();
        for (ReservationDBO reservation : reservations) {
            SeatDBO seat = reservation.getSeatDBO();
            Map<String, Object> seatDetail = new HashMap<>();
            
            seatDetail.put("bookingId", reservation.getBookingId());
            seatDetail.put("seatLabel", seat.getSeatLabel());
            seatDetail.put("movieTitle", seat.getMovieScheduleDBO().getMovieDBO().getTitle());
            seatDetail.put("timeSlot", seat.getMovieScheduleDBO().getDateTime());
            seatDetail.put("theaterName", seat.getMovieScheduleDBO().getTheaterName());
            seatDetail.put("price", calculatePrice(reservation.getAge()));

            totalPrice += calculatePrice(reservation.getAge());
            seatsDetails.add(seatDetail);
        }

        summary.put("seatsDetails", seatsDetails);
        summary.put("totalPrice", totalPrice);

        return ResponseEntity.ok(summary);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteBooking(@RequestParam int bookingId) {
        int seatId = ReservationAccess.getSeatIdForBooking(bookingId);
        if (seatId == -1) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Booking not found.");
        }

        boolean bookingDeleted = ReservationAccess.deleteBookingById(bookingId);
        boolean seatUpdated = SeatAccess.makeSeatAvailable(seatId);

        if (bookingDeleted && seatUpdated) {
            return ResponseEntity.ok("Booking deleted and seat made available.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to delete booking or reset seat availability.");
        }
    }

    @PostMapping("/confirm")
    public ResponseEntity<String> confirmBookings(@RequestParam String email) {
        // Step 1: Update is_checked_out to 1
        List<ReservationDBO> reservations = ReservationAccess.getNotCheckedOutBookingsByEmail(email);
        if (reservations == null || reservations.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No pending reservations found for confirmation.");
        }

        boolean allUpdated = true;
        for (ReservationDBO booking : reservations) {
            boolean updated = ReservationAccess.updateCheckedOutStatus(booking.getBookingId(), true);
            if (!updated) allUpdated = false;
        }

        if (!allUpdated) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update booking confirmation status.");
        }

        // Step 2: Send confirmation email
        StringBuilder emailBody = new StringBuilder("Your booking confirmation:\n\n");
        for (ReservationDBO booking : reservations) {
            emailBody.append("Movie: ")
                    .append(booking.getSeatDBO().getMovieScheduleDBO().getMovieDBO().getTitle())
                    .append("\nTheater: ").append(booking.getSeatDBO().getMovieScheduleDBO().getTheaterName()) // Add theater name
                    .append("\nSeat: ").append(booking.getSeatDBO().getSeatLabel())
                    .append("\nTime: ").append(booking.getSeatDBO().getMovieScheduleDBO().getDateTime())
                    .append("\n\n");
        }
        emailBody.append("Thanks for booking with us!"); // Add thank-you message at the bottom

        try {
            emailSenderService.sendEmail(email, "Your Booking Confirmation", emailBody.toString());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Email sending failed.");
        }

        // Step 3: Update email_sent to 1
        allUpdated = true;
        for (ReservationDBO booking : reservations) {
            boolean updated = ReservationAccess.updateEmailSentStatus(booking.getBookingId(), true);
            if (!updated) allUpdated = false;
        }

        if (!allUpdated) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update email sent status for bookings.");
        }

        return ResponseEntity.ok("Bookings confirmed, email sent successfully.");
    }

    @CrossOrigin(origins = "http://localhost:3000") // Allow requests from your React app
    @GetMapping("/promotion")
    public ResponseEntity<Map<String, Double>> getPromotion(@RequestParam String promoCode) {
        double promoPercentage = PromotionAccess.getPromoPercentage(promoCode);

        if (promoPercentage < 0) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("percentage", 0.0));
        } else if (promoPercentage == 0.0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("percentage", 0.0));
        }

        return ResponseEntity.ok(Map.of("percentage", promoPercentage));
    } // getPromotion


    private double calculatePrice(int age) {
        if (age <= 12) return 8.0;
        if (age >= 60) return 10.0;
        return 12.0;
    }
}
