package com.yourgroup.cinemaebooking.accessors;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.yourgroup.cinemaebooking.DatabaseObjects.*;

public class ScheduleAccess {
    private static final String url = "jdbc:mysql://cinema-booking.cfysagqmu79l.us-east-2.rds.amazonaws.com:3306/cinema_booking";
    private static final String username = "cameran";
    private static final String password = "Candawg34!";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    } // getConnection

    public static int addSchedule(int movieId, String dateTime, String theaterName) {
        String sql = "INSERT INTO movieSchedule (movie_id, date_time, theater_name) VALUES (?, ?, ?)";
        try (Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setInt(1, movieId);
            ps.setString(2, dateTime);
            ps.setString(3, theaterName);
            ps.executeUpdate();

            // Retrieve the generated keys
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    // Return the generated key (ID) for the new showing
                    return rs.getInt(1); // Assuming the ID is the first column
                } else {
                    return -1; // Error if no generated key is found
                } // if
            } // try

        } catch (SQLIntegrityConstraintViolationException e) {
            e.printStackTrace();
            return -2; // Movie already scheduled for date, time, and theater
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Other error scheduling movie
        } // try

    } // addSchedule

    public static int deleteSchedule(int movieId, String dateTime, String theaterName) {
        String sql = "DELETE FROM movieSchedule WHERE movie_id=? AND date_time=? AND theater_name=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, movieId);
            ps.setString(2, dateTime);
            ps.setString(3, theaterName);
            
            // Execute the update to delete the record
            int rowsAffected = ps.executeUpdate();

            // If rowsAffected is 0, no record was deleted
            if (rowsAffected == 0) {
                return 0; // No schedule found to delete
            } // if

        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Error deleting schedule
        } // try

        return 1; // Schedule deleted successfully
    } // deleteSchedule

    public static List<String> getSchedules(int movieId) {
        String sql = "SELECT * FROM movieSchedule WHERE movie_id=?";
        List<String> scheduleList = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, movieId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String dateTime = rs.getString("date_time");
                    System.out.println("dateTime");
                    dateTime = dateTime.substring(0, dateTime.length() - 3);
                    dateTime += ("$" + rs.getString("theater_name"));
                    System.out.println(dateTime);
                    scheduleList.add(dateTime);
                } // while
            } // try

            // Sort by datetime, then by theater name
            Collections.sort(scheduleList, new Comparator<String>() {
                @Override
                public int compare(String s1, String s2) {
                    // Split datetime and theater name
                    String[] parts1 = s1.split("\\$");
                    String[] parts2 = s2.split("\\$");

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                    LocalDateTime dt1 = LocalDateTime.parse(parts1[0], formatter);
                    LocalDateTime dt2 = LocalDateTime.parse(parts2[0], formatter);

                    // First, compare by datetime
                    int dateComparison = dt1.compareTo(dt2);
                    if (dateComparison != 0) {
                        return dateComparison;
                    } // if

                    // If datetime is the same, compare by theater name
                    return parts1[1].compareTo(parts2[1]);
                } // compare
            });

            return scheduleList;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } // try
    } // getSchedules

    public static int getShowingId(String datetime, String theaterName) {
        String sql = "SELECT id FROM movieSchedule WHERE date_time=? AND theater_name=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, datetime);
            ps.setString(2, theaterName);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                } else {
                    return 0;
                } // if
            } // try

        } catch (SQLException e) {
            e.printStackTrace();
        } // try

        return -1;
    } // getShowingId

    public static MovieScheduleDBO getSchedule(int id) {
        String sql = "SELECT * FROM movieSchedule WHERE id=?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new MovieScheduleDBO(id, rs.getInt("movie_id"), rs.getString("date_time"), rs.getString("theater_name"));
                } else { // Booking not found
                    return null;
                } // if
            } // try

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } // try
    } // getSchedule

} // ScheduleAccess
