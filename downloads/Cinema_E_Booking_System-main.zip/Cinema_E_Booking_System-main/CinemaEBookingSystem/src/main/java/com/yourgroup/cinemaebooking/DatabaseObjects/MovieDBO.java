package com.yourgroup.cinemaebooking.DatabaseObjects;

public class MovieDBO {
    private int movieId;
    private String title;
    private String status;
    private String trailerLink;
    private String trailerPic;
    private String rating;
    private String banner;
    private String genre;

    public MovieDBO(int id, String ttl, String sts, String tLink, String tPic, String rtg, String bnr, String gnr) {
        this.movieId = id;
        this.title = ttl;
        this.status = sts;
        this.trailerLink = tLink;
        this.trailerPic = tPic;
        this.rating = rtg;
        this.banner = bnr;
        this.genre = gnr;
    } // constructor

    // Getters and Setters
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTrailerLink() {
        return trailerLink;
    }

    public void setTrailerLink(String trailerLink) {
        this.trailerLink = trailerLink;
    }

    public String getTrailerPic() {
        return trailerPic;
    }

    public void setTrailerPic(String trailerPic) {
        this.trailerPic = trailerPic;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

} // MovieDBO
