package com.yourgroup.cinemaebooking.controllers;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;


import com.yourgroup.cinemaebooking.accessors.ReservationAccess;
import com.yourgroup.cinemaebooking.accessors.ScheduleAccess;
import com.yourgroup.cinemaebooking.accessors.SeatAccess;
import com.yourgroup.cinemaebooking.DTOs.BookingDataDTO;
import com.yourgroup.cinemaebooking.DTOs.SeatAgeDTO;
import com.yourgroup.cinemaebooking.EmailSenderService;
import com.yourgroup.cinemaebooking.DatabaseObjects.ReservationDBO;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/showings")
public class BookingController {
    @Autowired
    private EmailSenderService emailSenderService;

    @GetMapping("/unavailable-seats")
    public String[] getUnavailableSeats(@RequestParam String showtime) {
        System.out.println(showtime);
        int theaterIndex = showtime.indexOf("Theater");
        String datetimeString = showtime.substring(0, theaterIndex - 1);
        String theaterName = showtime.substring(theaterIndex);
        int showingId = ScheduleAccess.getShowingId(datetimeString, theaterName);
        System.out.println("Fetching unavailable seats for showingId: " + showingId);
        List<String> list = SeatAccess.getUnavailableSeatsForShowtime(showingId);
        return list.toArray(new String[list.size()]);
    } // getUnavailableSeats

    @PostMapping("/savebooking")
    public ResponseEntity<Map<String, String>> saveBooking(@RequestBody BookingDataDTO bookingData) {
        System.out.println("Saving booking...");
        Map<String, String> response = new HashMap<>();
        int theaterIndex = bookingData.getSelectedTime().indexOf("Theater");
        String datetimeString = bookingData.getSelectedTime().substring(0, theaterIndex - 1);
        String theaterName = bookingData.getSelectedTime().substring(theaterIndex);
        int showingId = ScheduleAccess.getShowingId(datetimeString, theaterName);

        List<SeatAgeDTO> selectedSeats = bookingData.getSelectedSeats();
        String[] seatLabels = new String[selectedSeats.size()];
        String[] ages = new String[selectedSeats.size()];
        for (int i = 0; i < selectedSeats.size(); i++) {
            seatLabels[i] = selectedSeats.get(i).getSeat();
            ages[i] = selectedSeats.get(i).getAge();
        } // for

        List<Integer> seatIds =  SeatAccess.getSeatIds(showingId, seatLabels);
        int[] seatIdsIntArray = new int[seatIds.size()];
        for (int i = 0; i < seatIds.size(); i++) {
            seatIdsIntArray[i] = seatIds.get(i);
        } // for

        int success;
        if (seatIdsIntArray.length == ages.length) { // makes sure it got the right number of seat ids
            success = ReservationAccess.saveReservations(bookingData.getEmail(), seatIdsIntArray, ages);
        } else {
            success = 0;
        } // if

        if (success == 1) { // Case for successful saving of reservations
            response.put("message", "Reservations saved successfully");
            return ResponseEntity.ok(response);
        } else if (success == 0) { // Case for if seatIds length didn't match ages length
            response.put("message", "Potential error in getting seat ids from server");
            return ResponseEntity.status(500).body(response);
        } else { // Case for sql server error
            response.put("message", "Internal server error");
            return ResponseEntity.status(500).body(response);
        } // if

    } // saveBooking

    @PostMapping("/emailBooking")
    public void emailBooking(@RequestParam String email) {
        List<ReservationDBO> bookings = ReservationAccess.getCheckedOutBookingsByEmail(email);

        String body = "Congrats on booking your tickets! \n\nHere are your recent bookings:\n";

        for (ReservationDBO booking : bookings) {
            body += "Booking ID: " + booking.getBookingId() + "\n"
                  + "Movie Title: " + booking.getSeatDBO().getMovieScheduleDBO().getMovieDBO().getTitle() + "\n"
                  + "Seat: " + booking.getSeatDBO().getSeatLabel() + "\n"
                  + "Time Slot " + booking.getSeatDBO().getMovieScheduleDBO().getDateTime() + "\n"
                  + "Age of customer: " + booking.getAge() + "\n";
        }

        body += "Thank you for booking with ECinema!";
        emailSenderService.sendEmail(email, "Bookings", body); 
    } // emailBooking

} // BookingController
