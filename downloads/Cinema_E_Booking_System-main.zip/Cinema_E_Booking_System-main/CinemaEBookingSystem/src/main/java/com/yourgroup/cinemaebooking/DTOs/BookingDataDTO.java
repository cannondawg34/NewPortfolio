package com.yourgroup.cinemaebooking.DTOs;

import java.util.List;

public class BookingDataDTO {
    private String email;
    private String selectedTime;
    private List<SeatAgeDTO> selectedSeats;

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String newEmail) {
        this.email = newEmail;
    }

    public String getSelectedTime() {
        return this.selectedTime;
    }

    public void setSelectedTime(String newSelectedTime) {
        this.selectedTime = newSelectedTime;
    }

    public List<SeatAgeDTO> getSelectedSeats() {
        return this.selectedSeats;
    }

    public void setSelectedSeats(List<SeatAgeDTO> newSelectedSeats) {
        this.selectedSeats = newSelectedSeats;
    }

} // BookingDataDTO
