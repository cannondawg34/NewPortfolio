package com.yourgroup.cinemaebooking.controllers;

import org.springframework.web.bind.annotation.*;

import com.yourgroup.cinemaebooking.accessors.ScheduleAccess;
import com.yourgroup.cinemaebooking.accessors.SeatAccess;
import com.yourgroup.cinemaebooking.objects.MovieObject;
import com.yourgroup.cinemaebooking.requests.DeleteScheduleRequest;
import com.yourgroup.cinemaebooking.requests.ScheduleRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@CrossOrigin(origins = "http://localhost:3000", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
@RequestMapping("/api/movies")
public class AdminController {

    @PostMapping("/add")
    public ResponseEntity<String> addMovie(@RequestBody MovieObject movie) {

      System.out.println("Received movie: " + movie.getTitle());
      movie.saveMovie();
      int id = movie.getID();
      if (id == 0) {
          // case for movie already exists
          return new ResponseEntity<>("Movie with same title already exists", HttpStatus.BAD_REQUEST);
      } else if (id == -1) {
          // case for error adding to db
          return new ResponseEntity<>("Error adding movie to server", HttpStatus.INTERNAL_SERVER_ERROR);
      } else {
          return new ResponseEntity<>("Movie added successfully", HttpStatus.OK);
      } // if
      
    } // addMovie

    @PostMapping("/schedule")
    public ResponseEntity<String> addSchedule(@RequestBody ScheduleRequest request) {
        System.out.println("Scheduling movie:");
        System.out.println("Date: " + request.getDate());
        System.out.println("Time: " + request.getTime());
        System.out.println("MovieId: " + request.getMovieId());
        int result = ScheduleAccess.addSchedule(request.getMovieId(), convertToDateTime(request.getDate(), request.getTime()), request.getTheaterName());
        if (result > 0) {
            SeatAccess.createSeatsForNewShowing(result);
            return ResponseEntity.ok("Movie scheduled successfully.");
        } else if (result == -2) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Another movie is already scheduled for this time.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to schedule movie.");
        } // if
    } // addSchedule

    @DeleteMapping("/schedule")
    public ResponseEntity<String> deleteSchedule(@RequestBody DeleteScheduleRequest request) {
        System.out.println("Deleting showing:");
        System.out.println("Date: " + request.getDate());
        System.out.println("Time: " + request.getTime());
        System.out.println("MovieId: " + request.getMovieId());
        System.out.println("Theater: " + request.getTheater());
        int result = ScheduleAccess.deleteSchedule(request.getMovieId(), convertToDateTime(request.getDate(), request.getTime()), request.getTheater());
        if (result == 1) {
            return ResponseEntity.ok("Showing deleted successfully.");
        } else if (result == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No such showing found to delete.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete showing.");
        } // if
    } // deleteSchedule

    @GetMapping("/schedule/{title}")
    public MovieObject getMovieSchedule(@PathVariable String title) {
        System.out.println("T1");
        MovieObject movie = new MovieObject(title);
        return movie;
    } // getMovieSchedule

    private String convertToDateTime(String date, String time) {
        return date + " " + time + ":00";
    } // convertToDateTime
} // AdminController
