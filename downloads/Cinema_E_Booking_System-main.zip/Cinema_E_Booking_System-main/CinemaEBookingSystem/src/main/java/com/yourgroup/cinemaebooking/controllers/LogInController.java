package com.yourgroup.cinemaebooking.controllers;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.yourgroup.cinemaebooking.accessors.UserAccess;
import com.yourgroup.cinemaebooking.objects.User;
import com.yourgroup.cinemaebooking.requests.LoginRequest;
import com.yourgroup.cinemaebooking.utilities.PasswordUtility;
import com.yourgroup.cinemaebooking.EmailSenderService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/login")
public class LogInController {

    @Autowired
    private EmailSenderService emailSenderService;

    @PostMapping
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
        String validationResult = validateUser(request.getEmail(), request.getPassword());
        Map<String, Object> response = new HashMap<>();

        switch (validationResult) {
            case "ADMIN" :
                response.put("message", "Admin login successful");
                response.put("isLoggedIn", true);
                response.put("username", request.getEmail());
                response.put("isAdmin", true);
                return ResponseEntity.ok(response);
            case "SUCCESS":
                response.put("message", "Login successful");
                response.put("isLoggedIn", true);
                response.put("username", request.getEmail());
                response.put("isAdmin", false);
                return ResponseEntity.ok(response);

            case "NOT_VERIFIED":
                response.put("message", "Account is not verified. Press the button to resend the verification code.");
                response.put("isLoggedIn", false);
                response.put("statusCode", "NOT_VERIFIED");
                return ResponseEntity.status(403).body(response);

            case "INVALID_CREDENTIALS":
                response.put("message", "Invalid username or password");
                response.put("isLoggedIn", false);
                return ResponseEntity.status(401).body(response);

            default:
                response.put("message", "An unexpected error occurred");
                response.put("isLoggedIn", false);
                return ResponseEntity.status(500).body(response);
        } // switch

        // return ResponseEntity.ok("Login successful");
    } // login

    @PostMapping("/resend-verification")
    public ResponseEntity<Map<String, String>> resendVerificationCode(@RequestBody User user) {
        String email = user.getEmail();

        Random random = new Random();
        int min = 100000;
        int max = 999999;
        int randomCode = random.nextInt((max - min) + 1) + min;
        String body = "Your new 6-digit verification code is: " + randomCode + "\n";
        body += "(If this wasn't you, ignore this email)";

        emailSenderService.sendEmail(email, "Account Verification", body);
        System.out.println("Email sent successfully");

        user.setVerifCode(randomCode);
        UserAccess.setVerificationCode(email, randomCode);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Verification code resent to your email.");
        return ResponseEntity.ok(response);
    } // resendVerificationCode

    @PostMapping("/verify-code")
    public ResponseEntity<Map<String, String>> verifyCode(@RequestBody Map<String, String> requestBody) {
        String email = requestBody.get("email");
        User user = UserAccess.findByEmail(email);
        int code = Integer.valueOf(requestBody.get("verificationCode"));

        boolean isVerified = (code == user.getVerifCode());
        Map<String, String> response = new HashMap<>();

        if (isVerified) {
            user.setVerified(true);
            UserAccess.verifyUser(email);
            response.put("message", "Account verified successfully.");
            return ResponseEntity.ok(response);
        } else {
            response.put("message", "Invalid verification code.");
            return ResponseEntity.status(403).body(response);
        } // if
    } // verifyCode

    private String validateUser(String email, String password) {
        if (UserAccess.checkForEmail(email) == 1) {
            System.out.println("Email found in db");

            if (PasswordUtility.verifyPass(password, UserAccess.getHashedPass(email))) {
                System.out.println("Password matches");
                int isVerified = UserAccess.isVerified(email);

                if (isVerified == 0) {
                    return "NOT_VERIFIED";
                } else if (isVerified == -1) {
                    return "VERIF_ERROR";
                } else {
                    if (UserAccess.isAdmin(email) == 1) {
                        return "ADMIN";
                    } else {
                        return "SUCCESS";
                    } // if
                } // if
            } else {
                System.out.println("Password does NOT match");
                return "INVALID_CREDENTIALS";
            } // if
        } else {
            System.out.println("Email NOT found in db");
            return "INVALID_CREDENTIALS";
        } // if
    } // validateUser

} // LogInController