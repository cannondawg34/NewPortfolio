package com.yourgroup.cinemaebooking.accessors;

import java.sql.*;
import java.util.*;

import com.yourgroup.cinemaebooking.DatabaseObjects.*;

public class SeatAccess {
    private static final String url = "jdbc:mysql://cinema-booking.cfysagqmu79l.us-east-2.rds.amazonaws.com:3306/cinema_booking";
    private static final String username = "cameran";
    private static final String password = "Candawg34!";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    } // getConnection

    public static int createSeatsForNewShowing(int showingId) {
        String sql = "INSERT INTO seats (showing_id, seat_label, is_available) VALUES ";
        for (char i = 'A'; i <= 'H'; i++) {
            for (int j = 1; j <= 8; j++) {
                sql += "(" + showingId + ", '" + i + j + "', TRUE)";
                if ((i == 'H') && (j == 8)) {
                    sql += ";"; // Makes sure (1, 'H8', TRUE) has ';' after instead of ', '
                } else {
                    sql += ", ";
                } // if
            } // for
        } // for
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return 1;
            } else {
                return 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Other error scheduling movie
        } // try  

    } // createSeatsForNewShowing

    public static List<String> getUnavailableSeatsForShowtime(int showtime) {
        String sql = "SELECT seat_label FROM seats WHERE showing_id=? AND is_available='0'";
        List<String> unavailableSeats = new ArrayList<String>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, showtime);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    unavailableSeats.add(rs.getString("seat_label"));
                } // while
            } // try

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } // try

        return unavailableSeats;
    } // getUnavailableSeatsForShowtime

    public static List<Integer> getSeatIds(int showingId, String[] seatLabels) {
        List<Integer> list = new ArrayList<Integer>();
        String sql = "SELECT seat_id FROM seats WHERE (showing_id, seat_label) IN (";
        for (int i = 0; i < seatLabels.length; i++) { // Constructs rest of SQL string
            sql += "(" + showingId + ", '" + seatLabels[i] + "')";
            if (i == (seatLabels.length - 1)) {
                sql += ");";
            } else {
                sql += ", ";
            } // if
        } // for

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getInt("seat_id"));
                } // while
            } // try
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } // try

        return list;
    } // getSeatIds

    public static SeatDBO getSeat(int seatId) {
        String sql = "SELECT * FROM seats WHERE seat_id=?";
        
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
       
            ps.setInt(1, seatId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) { // seat was found
                    return new SeatDBO(seatId, rs.getInt("showing_id"), rs.getString("seat_label"));
                } else { // seat was NOT found
                    return null;
                } // if
            } // try

        } catch (SQLException e) { // server error
            e.printStackTrace();
            return null;
        } // try

    } // getSeat

    public static int makeSeatUnavailable(int seatId) {
        String sql = "UPDATE seats SET is_available = 0 WHERE seat_id=?";
        try (Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement(sql)) {
  
        ps.setInt(1, seatId);

        if (ps.executeUpdate() == 0) {
            return 0;
        }

        return 1;

        } catch (SQLException e) { // server error
            e.printStackTrace();
            return -1;
        } // try
        
    } // makeSeatUnavailable

    public static boolean makeSeatAvailable(int seatId) {
        String sql = "UPDATE seats SET is_available = 1 WHERE seat_id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, seatId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Return true if the seat was updated successfully
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    } // makeSeatAvailable    

} // SeatAccess
