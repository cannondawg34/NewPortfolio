package com.yourgroup.cinemaebooking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class MovieApplication {

    @Autowired
    private EmailSenderService emailSenderService;

    public static void main(String[] args) {
        SpringApplication.run(MovieApplication.class, args);
    }

    /*
    @EventListener(ApplicationReadyEvent.class)
    public void testEmail() {
        System.out.println("Sending test email...");
        emailSenderService.sendEmail(
            "sonicclub20@gmail.com",  // Replace with a valid test email
            "Test Email",
            "This is a test email from ECinema."
        );
    }
    */
}
