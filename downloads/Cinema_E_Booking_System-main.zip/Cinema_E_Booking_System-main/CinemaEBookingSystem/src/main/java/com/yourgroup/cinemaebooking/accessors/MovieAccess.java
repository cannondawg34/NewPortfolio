package com.yourgroup.cinemaebooking.accessors;

import java.sql.*;
import java.util.*;

import com.yourgroup.cinemaebooking.DatabaseObjects.MovieDBO;
import com.yourgroup.cinemaebooking.objects.MovieObject;

public class MovieAccess {
    private static final String url = "jdbc:mysql://cinema-booking.cfysagqmu79l.us-east-2.rds.amazonaws.com:3306/cinema_booking";
    private static final String username = "cameran";
    private static final String password = "Candawg34!";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    } // getConnection
    
    private static String getFieldById(int id, String columnName) {
        String sql = "SELECT " + columnName + " FROM movies WHERE movie_id=?";
        
        try (Connection con = getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "ERR";
    }

    // Get the movie ID by title
    public static int getID(String title) {
        String sql = "SELECT movie_id FROM movies WHERE title=?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, title);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    /* Movie exists */
                    return rs.getInt(1);
                } // if
            } // try

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try
        
        return 0; // Movie does not exist

    } // getID

    public static String getTitle(int id) {
        return getFieldById(id, "title");
    } // getTitle
    
    public static String getStatus(int id) {
        return getFieldById(id, "status");
    } // getStatus

    public static String getTrailerLink(int id) {
        return getFieldById(id, "trailer_link");
    } // getTrailerLink

    public static String getTrailerPic(int id) {
        return getFieldById(id, "trailer_pic");
    } // getTrailerPic

    public static String getRating(int id) {
        return getFieldById(id, "rating");
    } // getRating

    public static String getGenre(int id) {
        return getFieldById(id, "genre");
    } // getGenre

    public static ArrayList<MovieObject> getAllMovies() {
        String sql = "SELECT * FROM movies";
        ArrayList<MovieObject> movies = new ArrayList<>();

        try (Connection con = getConnection(); 
             Statement st = con.createStatement(); 
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("movie_id");
                String title = rs.getString("title");
                String status = rs.getString("status");
                String trailerLink = rs.getString("trailer_link");
                String trailerPic = rs.getString("trailer_pic");
                String rating = rs.getString("rating");
                String genre = rs.getString("genre");

                System.out.println("ID: " + id + ", Title: " + title + ", Rating: " + rating + ", Genre: " + genre);

                MovieObject movie = new MovieObject(id, title, status, trailerLink, trailerPic, rating, genre);
                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } // try

        return movies;

    } // getAllMovies

    public static int addMovie(MovieObject newMovie) {
        /* -1 is returned if there is an SQL error
         * 0 is returned if the movie already exists (same title)
         * movieId is returned if the movie is successfully added
         */
        if (getID(newMovie.getTitle()) != 0) {
            /* Movie already exists */
            System.out.println("testBAD");
            return 0;
        } // if

        String sql = "INSERT INTO movies (title, status, trailer_link, trailer_pic, rating, genre) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, newMovie.getTitle());
            ps.setString(2, newMovie.getStatus());
            ps.setString(3, newMovie.getTrailerLink());
            ps.setString(4, newMovie.getTrailerPic());
            ps.setString(5, newMovie.getRating());
            ps.setString(6, newMovie.getGenre());

            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                    /* Returns the movie_id from the database table */
                } // if
            } // try
            
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try

        return -1;

    } // addMovie

    public static MovieDBO getMovie(int movieId) {
        String sql = "SELECT * FROM movies WHERE movie_id=?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, movieId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new MovieDBO(movieId, rs.getString("title"), rs.getString("status"), rs.getString("trailer_link"),
                                        rs.getString("trailer_pic"), rs.getString("rating"), rs.getString("banner"), rs.getString("genre"));
                } else { // Movie not found
                    return null;
                } // if
            } // try

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } // try

    } // getMovie

} // MovieAccess
