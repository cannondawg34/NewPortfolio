package com.yourgroup.cinemaebooking.accessors;

import java.sql.*;
import java.util.*;

import com.yourgroup.cinemaebooking.DatabaseObjects.*;

public class ReservationAccess {
    private static final String url = "jdbc:mysql://cinema-booking.cfysagqmu79l.us-east-2.rds.amazonaws.com:3306/cinema_booking";
    private static final String username = "cameran";
    private static final String password = "Candawg34!";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    } // getConnection

    public static int saveReservations(String email, int[] seatIds, String[] ages) {
        String sql = "INSERT INTO reservations (user_email, seat_id, age) VALUES ";
        for (int i = 0; i < seatIds.length; i++) { // builds sql query string
            sql += "('" + email + "', '" + seatIds[i] + "', '" + ages[i] + "')";
            if (i != (seatIds.length - 1)) {
                sql += ", ";
            } // if
        } // for
        sql += ";";

        System.out.println(sql);

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } // try

        for (int i = 0; i < seatIds.length; i++) {
            int x = SeatAccess.makeSeatUnavailable(seatIds[i]);
            if ((x == 0) || (x == -1)) {
                return x;
            } // if
        } // for

        return 1;
    } // saveReservations

    public static List<ReservationDBO> getBookingsByEmail(String email) {
        List<ReservationDBO> bookings = new ArrayList<ReservationDBO>();
        String sql = "SELECT * FROM reservations WHERE user_email=?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
                                
            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    bookings.add(new ReservationDBO(rs.getInt("booking_id"), email, rs.getInt("seat_id"), rs.getInt("age"),
                                                    rs.getInt("is_checked_out"), rs.getInt("email_sent")));
                } // while
            } // try

        } catch (SQLException e) { // Error getting reservation
            e.printStackTrace();
            return null;
        } // try

        return bookings;

    } // getBookingsByEmail

    public static List<ReservationDBO> getNotCheckedOutBookingsByEmail(String email) {
        List<ReservationDBO> bookings = new ArrayList<ReservationDBO>();
        String sql = "SELECT * FROM reservations WHERE user_email=? AND is_checked_out=0";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
                                
            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    bookings.add(new ReservationDBO(rs.getInt("booking_id"), email, rs.getInt("seat_id"), rs.getInt("age"),
                                                    rs.getInt("is_checked_out"), rs.getInt("email_sent")));
                } // while
            } // try

        } catch (SQLException e) { // Error getting reservation
            e.printStackTrace();
            return null;
        } // try

        return bookings;

    } // getNotCheckedOutBookingsByEmail

    public static List<ReservationDBO> getCheckedOutBookingsByEmail(String email) {
        List<ReservationDBO> bookings = new ArrayList<ReservationDBO>();
        String sql = "SELECT * FROM reservations WHERE user_email=? AND is_checked_out=1 AND email_sent=0";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
                                
            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    bookings.add(new ReservationDBO(rs.getInt("booking_id"), email, rs.getInt("seat_id"), rs.getInt("age"),
                                                    rs.getInt("is_checked_out"), rs.getInt("email_sent")));
                } // while
            } // try

        } catch (SQLException e) { // Error getting reservation
            e.printStackTrace();
            return null;
        } // try

        return bookings;

    } // getCheckedOutBookingsByEmail

    public static boolean deleteBookingById(int bookingId) {
        String sql = "DELETE FROM reservations WHERE booking_id = ?";
    
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Return true if deletion was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    } // deleteBookingById

    public static int getSeatIdForBooking(int bookingId) {
        String sql = "SELECT seat_id FROM reservations WHERE booking_id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, bookingId); // Set the booking ID parameter
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("seat_id"); // Return the seat ID if found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Print SQL exception for debugging
        }
        return -1; // Return -1 if the booking or seat is not found
    } // getSeatIdForBooking

    public static boolean updateCheckedOutStatus(int bookingId, boolean isCheckedOut) {
        String sql = "UPDATE reservations SET is_checked_out = ? WHERE booking_id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, isCheckedOut);
            ps.setInt(2, bookingId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean updateEmailSentStatus(int bookingId, boolean emailSent) {
        String sql = "UPDATE reservations SET email_sent = ? WHERE booking_id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, emailSent);
            ps.setInt(2, bookingId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

} // ReservationAccess
