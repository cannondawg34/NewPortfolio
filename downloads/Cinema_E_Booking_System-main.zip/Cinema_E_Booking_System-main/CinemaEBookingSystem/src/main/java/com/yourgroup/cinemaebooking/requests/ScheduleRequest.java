package com.yourgroup.cinemaebooking.requests;

public class ScheduleRequest {
    private int movieId;
    private String date;
    private String time;
    private String theaterName;

    public int getMovieId() {
        return this.movieId;
    }

    public void setMovieId(int newId) {
        this.movieId = newId;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String newDate) {
        this.date = newDate;
    }

    public String getTime() {
        return this.time;
    }

    public void setTime (String newTime) {
        this.time = newTime;
    }

    public String getTheaterName() {
        return this.theaterName;
    }

    public void setTheaterName(String newTheaterName) {
        this.theaterName = newTheaterName;
    }
} // ScheduleRequest
