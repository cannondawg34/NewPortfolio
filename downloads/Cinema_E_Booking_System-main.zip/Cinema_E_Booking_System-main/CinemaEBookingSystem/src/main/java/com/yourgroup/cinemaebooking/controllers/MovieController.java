package com.yourgroup.cinemaebooking.controllers;

import org.springframework.web.bind.annotation.*;

import com.yourgroup.cinemaebooking.accessors.MovieAccess;
import com.yourgroup.cinemaebooking.objects.MovieObject;

import java.util.List;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/movies")
public class MovieController {
    
    @PostMapping("/search") // Change to POST
    public String searchTitle(@RequestBody MovieRequest request) {
        String title = request.getTitle(); // Extract title from request body
        if (title.isEmpty()) {
            return "Title parameter is required.";
        } // if

        MovieObject m = new MovieObject(title);
        if (m.getTitle().equalsIgnoreCase("ERR")) {
            return "ERR";
        } else if (m.getTitle().equalsIgnoreCase("DNE")) {
            return "DNE";
        } // if

        return m.toString();
    } // searchTitle

    @PostMapping("add")
    public String addMovie(@RequestBody MovieObject newMovie) {
        int result = MovieAccess.addMovie(newMovie);
        if (result == -1) {
            return "ERR";
        } else if (result == 0) {
            return "Movie already exists";
        }  // if
        return "Movie added successfully!";
    } // addMovie

    @GetMapping("/all")
    public List<MovieObject> getAllMovies() {
        return MovieAccess.getAllMovies();
    } // getAllMovies

} // MovieController

// Create a DTO for the request
class MovieRequest {
    private String title;

    public String getTitle() {
        return title;
    } // getTitle

    public void setTitle(String title) {
        this.title = title;
    } // setTitle

} // MovieRequest
