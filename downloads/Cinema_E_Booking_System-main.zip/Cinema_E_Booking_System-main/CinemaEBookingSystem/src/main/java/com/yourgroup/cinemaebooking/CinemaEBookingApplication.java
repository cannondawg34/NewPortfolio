package com.yourgroup.cinemaebooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaEBookingApplication {
    public static void main(String[] args) {
        SpringApplication.run(CinemaEBookingApplication.class, args);
    }
}

