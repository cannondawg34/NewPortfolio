# Import necessary libraries
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text

app = Flask(__name__)

# Configuration for database connection
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Candawg34!@localhost/video_game'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

@app.route("/home")
def home():
    return render_template("home.html")

@app.route("/", methods=['GET'])
def default_redirect():
    # Redirect the root URL to the home page
    return redirect(url_for('home'))

@app.route("/app", methods=['GET', 'POST'])
def queries():
    # Initialize variables
    game_reccs = []
    genry_query = None
    esrb_rating_query = None
    year_query = None

    metacritic_search = []
    dev_query = None
    pub_query = None
    platform_query = None

    highest_average_playtime_games = []
    genre_query_playtime = None
    platform_query_playtime = None

    top_global_sales_games = []  # For Query 4

    if request.method == 'POST':
        # Query 1 - Game Recommendations
        genry_query = request.form.get('genre name')
        esrb_rating_query = request.form.get('esrb rating')
        year_query = request.form.get('year_query')

        query1 = """
        SELECT DISTINCT(vg.name) AS "Video_Game", vgm.metacritic_rating AS "Metacritic_Rating", vg.release_date AS "Release_Date"
        FROM video_game vg
        JOIN video_game_metrics vgm ON vg.id = vgm.Video_Game_id
        JOIN video_game_part_of_genres vgg ON vg.id = vgg.Video_Game_Id
        JOIN genre g ON vgg.Genre_id = g.id
        WHERE vgm.metacritic_rating >= 75 
            AND vgm.suggestions_count > 100  
            AND vgm.esrb_rating LIKE :esrb_rating_query 
            AND g.name LIKE :genre_query 
            AND (YEAR(STR_TO_DATE(vg.release_date, '%m/%d/%Y')) >= 1980)
        ORDER BY vgm.metacritic_rating DESC
        LIMIT 5;
        """
        try:
            result1 = db.session.execute(
                text(query1),
                {'genre_query': f'%{genry_query}%', 'esrb_rating_query': f'%{esrb_rating_query}%'}
            )
            game_reccs = [
                {"Video_Game": col[0], "Metacritic_Rating": col[1], "Release_Date": col[2]}
                for col in result1
            ]
        except Exception as e:
            print(f"[ERROR] Error executing Query 1: {e}")

        #Query 2 - Gives highest rated games by metacritic produced by certain developers and publishers on their preffered platform
        dev_query = request.form.get('dev_query', '')  # Retrieve developer name
        pub_query = request.form.get('pub_query', '')  # Retrieve publisher name
        platform_query = request.form.get('platform_query', '')  # Retrieve platform name

        if dev_query or pub_query or platform_query:

            query2 = """
            SELECT DISTINCT 
                vg.name AS "Video Game",
                p.name AS "Platform",
                pub.name AS "Publisher",
                dev.name AS "Developer",
                vgm.metacritic_rating AS "Metacritic Rating",
                vg.release_date AS "Release Date"
            FROM 
                Video_Game vg
            JOIN 
                Developed_By db ON vg.id = db.Video_Game_id
            JOIN 
                Developer dev ON db.Developer_id = dev.id
            JOIN 
                Published_By pb ON vg.id = pb.Video_Game_id
            JOIN 
                Publisher pub ON pb.Publisher_id = pub.id
            JOIN 
                Played_On po ON vg.id = po.Video_Game_id
            JOIN 
                Platform p ON po.Platform_id = p.id
            -- Join with Video_Game_Metrics to get metrics
            JOIN 
                Video_Game_Metrics vgm ON vg.id = vgm.Video_Game_id
            WHERE 
                dev.name LIKE :dev_query
                AND (pub.name LIKE :pub_query)
                AND (p.name LIKE :platform_query) 
                AND vgm.metacritic_rating != -1
            ORDER BY 
                vgm.metacritic_rating DESC
            LIMIT 5;
            """
            try:
                result_2 = db.session.execute(text(query2), {'dev_query':f'%{dev_query}%','pub_query':f'%{pub_query}%', 'platform_query': f'%{platform_query}%'})
            
                metacritic_search = [{"Video_Game": col[0], "Platform": col[1], "Publisher": col[2], "Developer": col[3], "Metacritic Rating":col[4], "Release Date":col[5]} for col in result_2]
                
            except Exception as e:
                    print(f"[ERROR] Error executing Query 2: {e}")
            
        # #Testing to see if it outputs correctly
        # for game in metacritic_search:
        #     print(game)
        
        # for game in game_reccs:
        #     print(game)
            
        # Query 3 - High Average Playtimes
        genre_query_playtime = request.form.get('genre name playtime')
        platform_query_playtime = request.form.get('platform_query_playtime')
        query3 = """
        SELECT 
            vg.name AS "Video Game",
            MAX(p.name) AS "Platform",
            MAX(vgm.achievement_count) AS "Number of Achievements",
            MAX(vgm.playtime) AS "Average_Playtime"
        FROM Video_Game vg
        JOIN Played_On po ON vg.id = po.Video_Game_id
        JOIN Platform p ON po.Platform_id = p.id
        JOIN Video_Game_part_of_Genres vgg ON vg.id = vgg.Video_Game_id
        JOIN Genre g ON vgg.Genre_id = g.id
        JOIN Video_Game_Metrics vgm ON vg.id = vgm.Video_Game_id
        WHERE g.name LIKE :genre_query_playtime
            AND vgm.achievement_count > 10
            AND (:platform_query_playtime = '' OR p.name LIKE :platform_query_playtime)
        GROUP BY vg.name, vgm.metacritic_rating
        ORDER BY average_playtime DESC
        LIMIT 5;
        """
        try:
            result3 = db.session.execute(
                text(query3),
                {'genre_query_playtime': f'%{genre_query_playtime}%',
                 'platform_query_playtime': f'%{platform_query_playtime}%'}
            )
            highest_average_playtime_games = [
                {"Video Game": col[0], "Platform": col[1], "Number of Achievements": col[2],
                 "Average_Playtime": col[3]}
                for col in result3
            ]
        except Exception as e:
            print(f"[ERROR] Error executing Query 3: {e}")

        # Query 4 - Games with the Highest Global Sales by Platform
        platform_query_global_sales = request.form.get('platform_global_sales')  # New input from the user

        query4 = """
                SELECT 
                    vg.name AS video_game_name,
                    p.name AS platform_name,
                    vgs.sales AS global_sales
                FROM 
                    video_game_sales vgs
                JOIN 
                    video_game vg ON vgs.Video_Game_id = vg.id
                JOIN 
                    Played_On po ON vg.id = po.Video_Game_id
                JOIN 
                    Platform p ON po.Platform_id = p.id
                WHERE 
                    p.name = :platform_query
                ORDER BY 
                    vgs.sales DESC
                LIMIT 5;
                """
        try:
            # Execute Query 4
            result4 = db.session.execute(text(query4), {'platform_query': platform_query_global_sales})
            # Process the result to include platform_name
            top_global_sales_games = [
                {
                    "Video_Game_Name": col[0],  # Video Game Name
                    "Platform_Name": col[1],   # Platform Name
                    "Global_Sales": col[2],    # Global Sales
                }
                for col in result4
            ]
        except Exception as e:
            # Print error message if query execution fails
            print(f"[ERROR] Error executing Query 4: {e}")

    # Render the template with default or query results
    return render_template(
        'index.html',
        game_reccs=game_reccs,
        genry_query=genry_query,
        esrb_rating_query=esrb_rating_query,
        year_query=year_query,
        metacritic_search=metacritic_search,
        dev_query=dev_query,
        pub_query=pub_query,
        platform_query=platform_query,
        highest_average_playtime_games=highest_average_playtime_games,
        genre_query_playtime=genre_query_playtime,
        platform_query_playtime=platform_query_playtime,
        top_global_sales_games=top_global_sales_games
    )


if __name__ == "__main__":
    app.run(debug=True)
