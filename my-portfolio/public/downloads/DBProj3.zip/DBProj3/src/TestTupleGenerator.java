package src;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestTupleGenerator {
    public static void main(String[] args) {
        // Define the table schemas and setup
        var test = new TupleGeneratorImpl();

        test.addRelSchema("Student", "id name address status", "Integer String String String", "id", null);
        test.addRelSchema("Professor", "id name deptId", "Integer String String", "id", null);
        test.addRelSchema("Course", "crsCode deptId crsName descr", "String String String String", "crsCode", null);
        test.addRelSchema("Teaching", "crsCode semester profId", "String String Integer", "crsCode semester",
                new String[][]{{"profId", "Professor", "id"}, {"crsCode", "Course", "crsCode"}});
        test.addRelSchema("Transcript", "studId crsCode semester grade", "Integer String String String",
                "studId crsCode semester",
                new String[][]{{"studId", "Student", "id"}, {"crsCode", "Course", "crsCode"}, {"crsCode semester", "Teaching", "crsCode semester"}});

        // Define variable tuple counts for scaling
        int[] tupleSizes = {500, 1000, 2000, 5000, 10000};

        // Prepare data structure to store performance data for each indexing method
        Map<String, Long> performanceData = new HashMap<>();

        for (int size : tupleSizes) {
            System.out.println("Testing with " + size + " tuples");

            // Generate tuples for the defined size
            int[] tupleCounts = {size, size / 10, size / 10, size, size};
            Comparable[][][] generatedTuples = test.generate(tupleCounts);

            // Test with NoIndex
            testNoIndexMethod(generatedTuples, size, performanceData);

            // Test with TreeMap
            testIndexingMethod("TreeMap", generatedTuples, size, performanceData, TreeMap.class);

            // Test with HashMap
            testIndexingMethod("HashMap", generatedTuples, size, performanceData, HashMap.class);

            // Test with LinHashMap
            testIndexingMethod("LinHashMap", generatedTuples, size, performanceData, LinHashMap.class);
        }

        // Output performance data for further analysis
        outputPerformanceData(performanceData);
    }

    /**
     * Method to test NoIndex performance for select and join operations, using nanoseconds.
     */
    private static void testNoIndexMethod(Comparable[][][] generatedTuples, int size,
                                          Map<String, Long> performanceData) {
        try {
            System.out.println("\nTesting with NoIndex");

            // Create and populate tables for Student and Transcript without any indexing
            Table studentTable = createNoIndexTable("Student", generatedTuples[0],
                    new String[]{"id", "name", "address", "status"},
                    new Class[]{Integer.class, String.class, String.class, String.class}, "id");
            Table transcriptTable = createNoIndexTable("Transcript", generatedTuples[4],
                    new String[]{"studId", "crsCode", "semester", "grade"},
                    new Class[]{Integer.class, String.class, String.class, String.class}, "studId crsCode semester");

            // Measure time for NoIndex Select operation
            long selectStartTime = System.nanoTime();
            studentTable.noIndexSelect(new KeyType(new Comparable[]{1}));  // Replace '1' with a value in your data if necessary
            long selectEndTime = System.nanoTime();
            performanceData.put("NoIndex_Select_size_" + size, selectEndTime - selectStartTime);

            // Measure time for NoIndex Join operation
            long joinStartTime = System.nanoTime();
            studentTable.noIndexjoin("id", "studId", transcriptTable);
            long joinEndTime = System.nanoTime();
            performanceData.put("NoIndex_Join_size_" + size, joinEndTime - joinStartTime);

        } catch (Exception e) {
            System.err.println("Error testing with NoIndex: " + e.getMessage());
            e.printStackTrace();  // Print the full stack trace for more context on where the error is happening
        }
    }

    /**
     * Generalized method to test with different indexing methods (TreeMap, HashMap, LinHashMap).
     */
    private static void testIndexingMethod(String indexType, Comparable[][][] generatedTuples, int size,
                                           Map<String, Long> performanceData, Class<? extends Map> mapClass) {
        try {
            System.out.println("\nTesting with " + indexType + " indexing");

            // Create and populate tables for Student and Transcript with specified indexing type
            Table studentTable = createTableWithIndex(indexType, "Student", generatedTuples[0],
                    new String[]{"id", "name", "address", "status"},
                    new Class[]{Integer.class, String.class, String.class, String.class}, "id", mapClass);
            Table transcriptTable = createTableWithIndex(indexType, "Transcript", generatedTuples[4],
                    new String[]{"studId", "crsCode", "semester", "grade"},
                    new Class[]{Integer.class, String.class, String.class, String.class}, "studId crsCode semester", mapClass);

            // Measure time for Select operation
            long selectStartTime = System.nanoTime();
            studentTable.select(new KeyType(new Comparable[]{1}));  // Replace '1' with a value in your data if necessary
            long selectEndTime = System.nanoTime();
            performanceData.put(indexType + "_Select_size_" + size, selectEndTime - selectStartTime);

            // Measure time for Join operation
            long joinStartTime = System.nanoTime();
            studentTable.join("id", "studId", transcriptTable);
            long joinEndTime = System.nanoTime();
            performanceData.put(indexType + "_Join_size_" + size, joinEndTime - joinStartTime);

        } catch (Exception e) {
            System.err.println("Error testing with " + indexType + ": " + e.getMessage());
        }
    }

    /**
     * Creates a table without any indexing (NoIndex).
     */
    private static Table createNoIndexTable(String name, Comparable[][] tuples,
                                            String[] attributes, Class[] domains, String primaryKey) throws Exception {
        Table table = new Table(name, attributes, domains, primaryKey.split(" "));

        // Insert tuples without setting an index
        for (Comparable[] tuple : tuples) {
            table.insert(tuple);
        }
        return table;
    }

    /**
     * Creates a table with the specified indexing method (TreeMap, HashMap, LinHashMap).
     */
    private static Table createTableWithIndex(String indexType, String name, Comparable[][] tuples,
                                              String[] attributes, Class[] domains, String primaryKey,
                                              Class<? extends Map> mapClass) throws Exception {
        Table table = new Table(name, attributes, domains, primaryKey.split(" "));
        
        // Set indexing type based on the map class
        if (mapClass == LinHashMap.class) {
            table.setIndexType(new LinHashMap<>(KeyType.class, Comparable[].class));
        } else if (mapClass == TreeMap.class) {
            table.setIndexType(new TreeMap<KeyType, Comparable[]>());
        } else if (mapClass == HashMap.class) {
            table.setIndexType(new HashMap<KeyType, Comparable[]>());
        }

        for (Comparable[] tuple : tuples) {
            table.insert(tuple);
        }
        return table;
    }

    /**
     * Outputs the performance data, grouped by indexing type and operation, in nanoseconds.
     */
    private static void outputPerformanceData(Map<String, Long> performanceData) {
        // Maps to hold performance data grouped by indexing type
        Map<String, Map<String, Long>> groupedData = new HashMap<>();
        groupedData.put("NoIndex", new HashMap<>());
        groupedData.put("TreeMap", new HashMap<>());
        groupedData.put("HashMap", new HashMap<>());
        groupedData.put("LinHashMap", new HashMap<>());

        // Distribute data into appropriate groups
        for (Map.Entry<String, Long> entry : performanceData.entrySet()) {
            String key = entry.getKey();
            Long value = entry.getValue();
            if (key.startsWith("NoIndex")) {
                groupedData.get("NoIndex").put(key, value);
            } else if (key.startsWith("TreeMap")) {
                groupedData.get("TreeMap").put(key, value);
            } else if (key.startsWith("HashMap")) {
                groupedData.get("HashMap").put(key, value);
            } else if (key.startsWith("LinHashMap")) {
                groupedData.get("LinHashMap").put(key, value);
            }
        }

        // Output the data for each indexing type in specified order, grouped by select and join operations
        System.out.println("\nPerformance Data (Grouped by Indexing Type, in nanoseconds):");

        String[] indexOrder = {"NoIndex", "TreeMap", "HashMap", "LinHashMap"};

        for (String indexType : indexOrder) {
            System.out.println("\n" + indexType + ":");

            // Separate select and join values within each indexing type
            System.out.println("  Select Operation:");
            groupedData.get(indexType).entrySet().stream()
                .filter(entry -> entry.getKey().contains("Select"))
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> System.out.println("    " + entry.getKey() + ": " + entry.getValue() + " ns"));

            System.out.println("  Join Operation:");
            groupedData.get(indexType).entrySet().stream()
                .filter(entry -> entry.getKey().contains("Join"))
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> System.out.println("    " + entry.getKey() + ": " + entry.getValue() + " ns"));
        }
    }
}

